
import numpy as np
from scipy.optimize import minimize

# 从给定的代码中导入电网信息
from llmopf.powernet import get_ps

ps = get_ps()  # 电网的信息存储在名字叫 ps 的实例/变量中

def object_function(x):
    """
    最优潮流问题的目标函数，目标是保持电压稳定，使节点的电压尽量在参考电压附近。
    
    参数:
        x (np.ndarray): 优化变量，包含节点幅值、相角、发电机有功功率和无功功率。
        
    返回:
        float: 目标函数值，表示电压偏离参考电压的程度。
    """
    v = x[:ps.n]  # 节点幅值
    a = x[ps.n:2*ps.n]  # 节点相角
    p = x[2*ps.n:2*ps.n+ps.m]  # 发电机有功功率
    q = x[2*ps.n+ps.m:2*ps.n+ps.m+ps.m]  # 发电机无功功率

    # 计算每个节点电压与参考电压（标准电压）的偏差平方和
    reference_voltages = [bus.vn_kv for bus in ps.buses]
    voltage_deviation = (v - reference_voltages) ** 2
    
    # 目标是最小化电压偏离程度
    return np.sum(voltage_deviation)

def equality_constraints(x):
    """
    计算最优潮流的等式约束。
    
    参数:
        x (np.ndarray): 优化变量，包含电压幅值、相角、发电机有功和无功功率
        
    返回:
        list: 等式约束列表（每个节点的有功和无功平衡方程）
    """
    n = ps.n  # 节点数量
    v = x[:n]  # 节点电压幅值
    a = x[n:2*n]  # 节点相角
    p_gen = x[2*n:2*n+ps.m]  # 发电机有功功率
    q_gen = x[2*n+ps.m:2*n+2*ps.m]  # 发电机无功功率
    
    bp = [0.0] * n  # 每个节点的有功功率净注入
    bq = [0.0] * n  # 每个节点的无功功率净注入
    
    # 初始化每个节点的发电机功率为0
    node_p_gen = [0.0] * n
    node_q_gen = [0.0] * n
    
    # 将发电机功率分配到对应节点
    for i in range(ps.m):
        node_idx = ps.generators[i].node
        node_p_gen[node_idx] += p_gen[i]
        node_q_gen[node_idx] += q_gen[i]
    
    # 添加负荷功率
    for i in range(ps.k):
        node_idx = ps.loads[i].node
        bp[node_idx] = node_p_gen[node_idx] - ps.loads[i].p_demand
        bq[node_idx] = node_q_gen[node_idx] - ps.loads[i].q_demand
    
    # 添加静态发电机功率
    for i in range(ps.s):
        node_idx = ps.sgens[i].node
        bp[node_idx] = node_p_gen[node_idx] - ps.sgens[i].p_inject
        bq[node_idx] = node_q_gen[node_idx] - ps.sgens[i].q_inject
    
    constraints = []
    
    # 计算每个节点的有功和无功平衡方程
    for i in range(n):
        # 有功功率平衡方程
        P_i = sum(v[i] * v[j] * (ps.Y[i, j].real * np.cos(a[i] - a[j]) + ps.Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n))
        constraints.append(P_i - bp[i])
        
        # 无功功率平衡方程
        Q_i = sum(v[i] * v[j] * (ps.Y[i, j].real * np.sin(a[i] - a[j]) - ps.Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n))
        constraints.append(Q_i - bq[i])
    
    return constraints

# 构建求解变量 x 的上下界 bounds 和初值 x0
bounds = []
x0 = []

# 节点电压幅值 v (单位: kV)
for i in range(ps.n):
    min_v = ps.buses[i].min_kv
    max_v = ps.buses[i].max_kv
    vn = ps.buses[i].vn_kv if hasattr(ps.buses[i], 'vn_kv') else (min_v + max_v) / 2  # 如果没有标准值，则取中间值
    bounds.append((min_v, max_v))
    x0.append(vn)

# 节点相角 a (单位: radian，通常无约束，但可以设为 -π 到 π)
for i in range(ps.n):
    bounds.append((-3.1416, 3.1416))  # -π to π
    x0.append(0.0)  # 初值设为 0

# 发电机有功功率 p (单位: MW)
for i in range(ps.m):
    min_p = ps.generators[i].min_p
    max_p = ps.generators[i].max_p
    p_initial = (min_p + max_p) / 2  # 初值设为中间值
    bounds.append((min_p, max_p))
    x0.append(p_initial)

# 发电机无功功率 q (单位: MVar)
for i in range(ps.m):
    min_q = ps.generators[i].min_q
    max_q = ps.generators[i].max_q
    q_initial = (min_q + max_q) / 2  # 初值设为中间值
    bounds.append((min_q, max_q))
    x0.append(q_initial)

# 将 x0 转换为 numpy 数组
x0 = np.array(x0)

# 定义等式约束的雅可比矩阵计算函数
def eq_jacobian(x):
    """
    计算等式约束的雅可比矩阵。
    
    参数:
        x (np.ndarray): 优化变量
        
    返回:
        np.ndarray: 雅可比矩阵
    """
    n = ps.n
    m = ps.m
    total_vars = len(x)
    jac = np.zeros((2 * n, total_vars))  # 2n 个等式约束（每个节点一个有功和一个无功）

    v = x[:n]
    a = x[n:2*n]
    p_gen = x[2*n:2*n+m]
    q_gen = x[2*n+m:2*n+2*m]

    # 初始化每个节点的发电机功率为0
    node_p_gen = [0.0] * n
    node_q_gen = [0.0] * n
    
    # 将发电机功率分配到对应节点
    for i in range(m):
        node_idx = ps.generators[i].node
        node_p_gen[node_idx] += p_gen[i]
        node_q_gen[node_idx] += q_gen[i]
    
    # 添加负荷功率
    for i in range(ps.k):
        node_idx = ps.loads[i].node
        node_p_gen[node_idx] -= ps.loads[i].p_demand
        node_q_gen[node_idx] -= ps.loads[i].q_demand
    
    # 添加静态发电机功率
    for i in range(ps.s):
        node_idx = ps.sgens[i].node
        node_p_gen[node_idx] -= ps.sgens[i].p_inject
        node_q_gen[node_idx] -= ps.sgens[i].q_inject

    # 计算雅可比矩阵
    for i in range(n):
        # 有功功率平衡方程对 v[i] 的偏导数
        dP_dvi = sum(v[j] * (ps.Y[i, j].real * np.cos(a[i] - a[j]) + ps.Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n))
        jac[2*i, i] = dP_dvi

        # 有功功率平衡方程对 a[i] 的偏导数
        dP_dai = sum(-v[i] * v[j] * (ps.Y[i, j].real * np.sin(a[i] - a[j]) - ps.Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n))
        jac[2*i, n+i] = dP_dai

        # 无功功率平衡方程对 v[i] 的偏导数
        dQ_dvi = sum(v[j] * (ps.Y[i, j].real * np.sin(a[i] - a[j]) - ps.Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n))
        jac[2*i+1, i] = dQ_dvi

        # 无功功率平衡方程对 a[i] 的偏导数
        dQ_dai = sum(v[i] * v[j] * (ps.Y[i, j].real * np.cos(a[i] - a[j]) + ps.Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n))
        jac[2*i+1, n+i] = dQ_dai

    return jac

# 使用内点法求解最优潮流问题
result = minimize(
    fun=object_function,
    x0=x0,
    method='SLSQP',
    bounds=bounds,
    constraints={'type': 'eq', 'fun': equality_constraints, 'jac': eq_jacobian}
)

# 提取结果
optimal_value = result.fun
v_opt = result.x[:ps.n]
a_opt = result.x[ps.n:2*ps.n]
p_opt = result.x[2*ps.n:2*ps.n+ps.m]
q_opt = result.x[2*ps.n+ps.m:2*ps.n+2*ps.m]

# 格式化输出结果
result_str = f'fun: {optimal_value:.6f}, v: {v_opt.tolist()}, a: {a_opt.tolist()}, p: {p_opt.tolist()}, q: {q_opt.tolist()}'
print(result_str)
