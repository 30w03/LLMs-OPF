from llmopf.powernet import get_ps

case = "case33"

ps = get_ps(case)
ps.textPrint(f'./data_net_info/{case}.txt')