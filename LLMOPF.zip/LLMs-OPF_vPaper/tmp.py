
import numpy as np
from scipy.optimize import minimize

from data_net_info.read_case import get_ps
ps = get_ps()  # 电网的信息存储在名字叫 ps 的实例/变量中

class OPFProblem:
    def __init__(self, ps):
        self.ps = ps
        self.num_nodes = ps.num_nodes
        self.num_generators = ps.num_generators
        self.buses = ps.buses

    def objective_function(self, x):
        v = x[:self.num_nodes]  # 节点幅值
        reference_voltages = [self.buses[i].nominal_voltage for i in range(self.num_nodes)]
        
        # 计算目标函数值
        objective_value = sum((v[i] - reference_voltages[i]) ** 2 for i in range(self.num_nodes))
        
        return objective_value

    def equality_constraints(self, x):
        n = self.num_nodes
        v = x[:n]  # 节点电压幅值
        a = x[n:2*n]  # 节点相角
        Y = self.ps.admittance_matrix  # 导纳矩阵
        
        constraints = []
        
        for i in range(n):
            # 计算该节点的有功功率注入 (P)
            P_i = sum(v[i] * v[j] * (Y[i][j].real * np.cos(a[i] - a[j]) + Y[i][j].imag * np.sin(a[i] - a[j])) for j in range(n))
            
            # 计算该节点的无功功率注入 (Q)
            Q_i = sum(v[i] * v[j] * (Y[i][j].real * np.sin(a[i] - a[j]) - Y[i][j].imag * np.cos(a[i] - a[j])) for j in range(n))
            
            # 计算该节点的净功率需求 (发电机输出 - 负荷消耗)
            P_net = 0
            Q_net = 0
            
            # 添加发电机功率
            for gen in self.ps.generators:
                if gen.node == i:
                    P_net += gen.active_power_limits[0]  # 假设使用最小值作为基准
                    Q_net += gen.reactive_power_limits[0]
            
            # 减去负荷功率
            for load in self.ps.loads:
                if load.node == i:
                    P_net -= load.power_demand[0]
                    Q_net -= load.power_demand[1]
            
            # 减去静态发电机功率
            for static_gen in self.ps.static_generators:
                if static_gen.node == i:
                    P_net -= static_gen.power_injection[0]
                    Q_net -= static_gen.power_injection[1]
            
            # 添加等式约束：注入功率 - 净功率需求 = 0
            constraints.append(P_i - P_net)
            constraints.append(Q_i - Q_net)
        
        return constraints

    def build_bounds_and_initial_guess(self):
        num_nodes = self.num_nodes
        num_generators = self.num_generators

        # 初始化 bounds 和 x0
        bounds = []
        x0 = []

        # 节点电压幅值 v 的上下界和初始值
        for i in range(num_nodes):
            min_v = self.buses[i].min_voltage  # 将 kV 转换为 V
            max_v = self.buses[i].max_voltage  # 将 kV 转换为 V
            nominal_v = self.buses[i].nominal_voltage if hasattr(self.buses[i], 'nominal_voltage') else (min_v + max_v) / 2
            bounds.append((min_v, max_v))
            x0.append(nominal_v)

        # 节点相角 a 的上下界和初始值（通常相角范围是 -π 到 π，初始值设为 0）
        for _ in range(num_nodes):
            bounds.append((-3.1416, 3.1416))  # 使用弧度表示的相角范围
            x0.append(0.0)

        # 发电机有功功率 p 的上下界和初始值
        for i in range(num_generators):
            gen_node = self.ps.generators[i].node
            active_min, active_max = self.ps.generators[i].active_power_limits  # 单位假设为 MW
            initial_p = (active_min + active_max) / 2  # 初始值取中间值
            bounds.append((active_min, active_max))  # 转换为 W
            x0.append(initial_p)

        # 发电机无功功率 q 的上下界和初始值
        for i in range(num_generators):
            reactive_min, reactive_max = self.ps.generators[i].reactive_power_limits  # 单位假设为 MVar
            initial_q = (reactive_min + reactive_max) / 2  # 初始值取中间值
            bounds.append((reactive_min, reactive_max))  # 转换为 Var
            x0.append(initial_q)

        # 返回结果
        bounds = tuple(bounds)
        x0 = np.array(x0)
        
        return bounds, x0

    def solve_opf(self):
        bounds, x0 = self.build_bounds_and_initial_guess()

        # 定义等式约束
        eq_cons = {'type': 'eq', 'fun': lambda x: self.equality_constraints(x)}

        # 使用内点法求解
        result = minimize(
            fun=self.objective_function,
            x0=x0,
            method='SLSQP',
            bounds=bounds,
            constraints=eq_cons
        )

        # 提取最优解
        v_opt = result.x[:self.num_nodes]
        a_opt = result.x[self.num_nodes:2*self.num_nodes]
        p_opt = result.x[2*self.num_nodes:2*self.num_nodes + self.num_generators]
        q_opt = result.x[2*self.num_nodes + self.num_generators:]

        # 格式化输出结果
        result_str = (
            f'fun: {result.fun:.4f}, '
            f'v: {np.round(v_opt, 4).tolist()}, '
            f'a: {np.round(a_opt, 4).tolist()}, '
            f'p: {np.round(p_opt, 4).tolist()}, '
            f'q: {np.round(q_opt, 4).tolist()}'
        )

        print(result_str)


# 创建问题实例并求解
opf_problem = OPFProblem(ps)
opf_problem.solve_opf()
