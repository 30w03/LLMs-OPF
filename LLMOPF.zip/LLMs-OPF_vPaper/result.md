# 实验结果

## 稳定性实验

相同 prompt，temperature=0.7/top_p=0.8

```python
origin_info = """
电网的信息存储在名字叫 ps 的 PowerSystem 类的实例中， ps 的定义如下：
import pandapower.networks as pn
from llmopf import powernet
ps = powernet.PowerSystem(pn.case5())
\"\"\"
ps.n # 电网的节点数量
ps.m # 电网的发电机数量
ps.k # 电网的负荷数量
ps.Y # 电网的导纳矩阵
ps.generators # 电网的发电机信息，是 List[Generator] 类型
# Generator 类有下面成员：发电机所在节点位置 node ，发电机成本系数 cp0 cp1 cp2 cq0 cq1 cq2 ，发电机功率限制 min_p max_p min_q max_q
ps.loads # 电网负荷信息，是 List[Load] 类型
# Load 类有下面成员：负荷所在节点位置 node ，负荷功率 p_demand q_demand
ps.buses # 电网节点的限制信息，是 List[Dict] 类型， Dict 有 'min_v', 'max_v' 两个键值
# 电压幅值单位是 kV ，电机功率和负荷功率是 mW 和 mVar
\"\"\"
"""

groundtruth = """
fun: 17491.852941161902, v: [252.071939   249.84725576 252.03706987 248.5269002  253.        ], a: [-2.00686521 -2.05942629 -2.05328375 -2.04877398 -1.98833309], p: [ 40.         364.39509804 600.        ], q: [ 30.         243.81504505  89.6262603 ]
"""
```

qwen-plus: 37/50 = 0.74
deepseek-v3: 18/50 = 0.36