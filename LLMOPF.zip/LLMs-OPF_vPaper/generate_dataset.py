from llmopf.utils.add_noise import generate_text_set
from llmopf.origin_info import origin_info_case5_obj1, origin_info_case9_obj2

p = './data_0402/case9obj2'

generate_text_set(origin_info_case9_obj2, p)