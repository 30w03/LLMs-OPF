import pandas as pd

def normalize_csv(input_csv_path, output_csv_path):
    # 读取 CSV 文件
    df = pd.read_csv(input_csv_path, index_col=0)
    
    # 找到数值项的最大绝对值
    max_abs_value = df.select_dtypes(include=['number']).abs().max().max()
    
    # 归一化数值项
    df_normalized = df.copy()  # 创建一个副本以保留原始 DataFrame
    df_normalized[df_normalized.select_dtypes(include=['number']).columns] /= max_abs_value
    
    # 输出到新的 CSV 文件，保留原来的索引
    df_normalized.to_csv(output_csv_path)  # index=False 不输出索引列

def perfect_csv(input_csv_path, output_csv_path, m):
    # 读取 CSV 文件
    df = pd.read_csv(input_csv_path, index_col=0)
    
    # 找到数值项的最大绝对值
    mean_value = df.select_dtypes(include=['number']).mean().mean()
    
    # 归一化数值项
    df_perfect = df.copy()  # 创建一个副本以保留原始 DataFrame
    df_perfect[df_perfect.select_dtypes(include=['number']).columns] /= mean_value
    df_perfect[df_perfect.select_dtypes(include=['number']).columns] *= m
    
    # 输出到新的 CSV 文件，保留原来的索引
    df_perfect.to_csv(output_csv_path)  # index=False 不输出索引列

# df_ep = pd.read_csv('data/profile_perfect/Electricity_price_profile.csv')

# mean1 = df_ep['buy_price'].mean()

# print('mean:', df_ep['buy_price'].mean())
# print('max: ', df_ep['buy_price'].max())
# print('min: ', df_ep['buy_price'].min())
# print('std: ', df_ep['buy_price'].std())

# df_ep = pd.read_csv('data/profile_raw/Electricity_price_profile.csv')

# mean2 = df_ep['buy_price'].mean()

# print('mean:', df_ep['buy_price'].mean())
# print('max: ', df_ep['buy_price'].max())
# print('min: ', df_ep['buy_price'].min())
# print('std: ', df_ep['buy_price'].std())

# print(mean2 / mean1)

# df_gp = pd.read_csv('data/profile_perfect/Gas_price_profile.csv')

# df_gp['price'] *= 0.02 * (mean2 / mean1)

# print('mean:', df_gp['price'].mean())
# print('max: ', df_gp['price'].max())
# print('min: ', df_gp['price'].min())
# print('std: ', df_gp['price'].std())

# # 去重 price 列
# unique_prices = df_gp['price'].drop_duplicates().to_list()

# for m in range(0, 12):
#     print(f'month {m+1}: {unique_prices[m]}')

csv_pos = './data_profile/'
csv_name = ['Wind_profile', 'PV_profile']
# csv_name = []

csv_dict = {
    'PV_profile': 1,
    'Wind_profile': 5,
    'Electricity_price_profile': 1,
    'Gas_price_profile': 50, 
    'load_profile': 1, 
    'sink_p_profile': 0.02, 
    'sink_m_profile': 0.02
}

csv_pos2 = './data_profile/'

for name in csv_name:
    m = csv_dict[name]
    input_path = csv_pos + name + '.csv'
    output_path = csv_pos2 + name + '.csv'
    perfect_csv(input_path, output_path, m)

