from response.qwen import get_response as ask_qwen
from response.local import get_response as ask_local
from utils.parse_output import parse_block, parse_tag
from utils.sft_format import make_message

import json

prompt_generate = """
## 背景
我需要生成一些数据
## 需求
根据下面的用户提示词
生成一个新的提示词，需要满足下面条件：
1. 大模型的回复能得到相同的结论
2. 不改变原来提示词的格式
## 用户提示词
[MASK:prompt]
## 回复格式
<think>
... // 写出你的思考过程
</think>
<prompt>
... 写出你生成的新提示词
</prompt>
## 生成的新的提示词
"""

prompt_check = """
## 背景
我需要生成一些数据
## 需求
根据正确答案，请帮我判断一份作答的正确性
## 正确答案
[MASK:correct]
## 需判断的作答
[MASK:generated]
## 格式
... // 你的分析
```judge
yes/no
```
## 你的回复
"""

prompt_summary_input = """
## 要求
下面是一段大模型生成的提示词和可能附有的生成思考解释，请去掉思考过程，提炼出生成的提示词部分。
## 内容
[MASK:content]
## 你的总结
"""

code = """
## 参考代码
power_net = pn.case5()
power_system = powernet.PowerSystem(power_net, 0)
# print(power_system)
n = power_system.n
m = power_system.m

def object_function(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    cost = 0

    for i, gen in enumerate(power_system.generators):
        cost += gen.cp2 * p[i] * p[i] + gen.cp1 * p[i] + gen.cp0
        cost += gen.cq2 * q[i] * q[i] + gen.cq1 * q[i] + gen.cq0
    
    return cost

def equality_constraints(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    Y = power_system.Y

    bp = np.zeros(n)
    bq = np.zeros(n)

    for i, gen in enumerate(power_system.generators):
        bp[gen.node] += p[i]
        bq[gen.node] += q[i]
    
    for load in power_system.loads:
        bp[load.node] -= load.p_demand
        bq[load.node] -= load.q_demand
    
    eq = []

    for i in range(n):
        pi = sum(v[i] * v[j] * (Y[i, j].real * np.cos(a[i] - a[j]) + Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n)) - bp[i]
        qi = sum(v[i] * v[j] * (Y[i, j].real * np.sin(a[i] - a[j]) - Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n)) - bq[i]

        eq.append(pi)
        eq.append(qi)
    
    return np.array(eq)

# 变量边界
v_bounds = [(bus['min_v'], bus['max_v']) for bus in power_system.buses]
a_bounds = [(-np.pi, np.pi)] * (n)
p_bounds = [(gen.min_p, gen.max_p) for gen in power_system.generators]
q_bounds = [(gen.min_q, gen.max_q) for gen in power_system.generators]

bounds = v_bounds + a_bounds + p_bounds + q_bounds

# 初始猜测值
initial_guess = np.zeros(n+n+m+m)
"""

prompt_summary = """
## 要求
请你根据一段回复信息，去掉思考过程，提炼出最终的结果部分，用 python 代码和注释总结。
## 回复信息
[MASK:reply]
## 格式要求
仅回复
```python``` 包裹住的代码块部分
## 你的总结
"""

def summary(response):
    return ask_qwen(prompt_summary.replace('MASK:reply', response))

def generate_sft_data(correct_input, correct_output, iter_times = 1):
    if (iter_times > 3):
        return None
    
    correct_output = summary(correct_output)

    p = prompt_generate
    p = p.replace('[MASK:prompt]', correct_input)
    p = p.replace('[MASK:response]', correct_output)

    new_p = ask_qwen(p, model='qwen-max')
    print(new_p)
    new_p = parse_tag(new_p, 'prompt')
    new_r = ask_qwen(new_p + code, model='qwen-max')

    print('++++++++++++++++++')

    print(new_p)
    print('------------------')
    print(new_r)
    
    return make_message(new_p, new_r)

def read_jsonl(file_path):
    """
    读取 JSON Lines 文件并返回一个包含所有 JSON 对象的列表。

    :param file_path: JSON Lines 文件的路径
    :return: 包含所有 JSON 对象的列表
    """
    data = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    # 解析每一行的 JSON 数据
                    json_obj = json.loads(line.strip())
                    data.append(json_obj)
                except json.JSONDecodeError as e:
                    print(f"解析 JSON 失败：{e}，行内容：{line.strip()}")
    except FileNotFoundError:
        print(f"文件未找到：{file_path}")
    except Exception as e:
        print(f"读取文件失败：{e}")
    return data

def generate_from_jsonl(file_path):
    data = read_jsonl(file_path)

    i = data[0]['message'][0]['content']
    o = data[0]['message'][1]['content']

    k = 0

    new_data = []

    while k < len(data):
        i = data[k]['message'][0]['content']
        o = data[k]['message'][1]['content']

        m = generate_sft_data(i, o)
        if (m is not None):
            new_data.append(m)

            # 将记录追加到 record.jsonl 文件
            with open("new_data_0324.jsonl", "a", encoding="utf-8") as f:
                f.write(json.dumps(m, ensure_ascii=False) + "\n")

        k += 2

for _ in range(100):
    generate_from_jsonl('groundtruth_0315.jsonl')