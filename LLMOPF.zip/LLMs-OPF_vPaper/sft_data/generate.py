from response.qwen import get_response as ask_qwen
from response.local import get_response as ask_local
from utils.parse_output import parse_block
from utils.sft_format import make_message

import json

prompt_generate = """
## background
I need to generate some data.
## task
Recording the following prompt and response, generate a different prompt.
The generated prompt must satisfy following points.
1. Summary the new response from the generated prompt keeping the same meaning with the old response.
2. Don't change the structure of the prompt.
3. Use English.
## prompt
[MASK:prompt]
## response
[MASK:response]
## The different generated English prompt
"""

prompt_check = """
## background
I need to generate some data.
## task
Here are a correct response and a generated response.
You need to judge the generated one whether keep the same meaning.
## correct response
[MASK:correct]
## generated response
[MASK:generated]
## exemple style
... // your analyse
```judge
yes/no
```
## your reply
"""

prompt_summary = """
## Requirement
Recording the following reply, take off the thinking part and summary the result using python code and comment.
## reply
[MASK:reply]
## format
only response the code block, without other content:
```python
...
```
## your summary (English)
"""

prompt_judge = """

"""

def summary(response):
    return ask_local(prompt_summary.replace('[MASK:reply]', response))

def generate_sft_data(correct_input, correct_output):
    correct_output = summary(correct_output)

    p = prompt_generate
    p = p.replace('[MASK:prompt]', correct_input)
    p = p.replace('[MASK:response]', correct_output)

    new_p = ask_qwen(p, model='qwen-max')
    new_r = ask_local(new_p)

    print(new_p, new_r)

    p = prompt_check
    p = p.replace('[MASK:correct]', correct_output)
    p = p.replace('[MASK:generated]', summary(new_r))

    judge_result = parse_block(ask_qwen(p, model='qwen-max'), 'judge')

    if (('yes' in judge_result) and ('no' not in judge_result)):
        return make_message(new_p, new_r)
    else:
        return generate_sft_data(correct_input, correct_output)

def read_jsonl(file_path):
    """
    读取 JSON Lines 文件并返回一个包含所有 JSON 对象的列表。

    :param file_path: JSON Lines 文件的路径
    :return: 包含所有 JSON 对象的列表
    """
    data = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    # 解析每一行的 JSON 数据
                    json_obj = json.loads(line.strip())
                    data.append(json_obj)
                except json.JSONDecodeError as e:
                    print(f"解析 JSON 失败：{e}，行内容：{line.strip()}")
    except FileNotFoundError:
        print(f"文件未找到：{file_path}")
    except Exception as e:
        print(f"读取文件失败：{e}")
    return data

data = read_jsonl('groundtruth_0314.jsonl')

i = data[0]['message'][0]['content']
o = data[0]['message'][1]['content']

k = 0

new_data = []

while k < len(data):
    i = data[k]['message'][0]['content']
    o = data[k]['message'][1]['content']

    m = generate_sft_data(i, o)
    new_data.append(m)

    # 将记录追加到 record.jsonl 文件
    with open("new_data.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(m, ensure_ascii=False) + "\n")

    k += 2

print(i, o)

print(generate_sft_data(i, o))