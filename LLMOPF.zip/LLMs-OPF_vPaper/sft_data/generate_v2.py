code = """
import pandapower.networks as pn
import numpy as np
from scipy.optimize import minimize

import powernet # local module

power_net = pn.case5()
power_system = powernet.PowerSystem(power_net, 0)
# print(power_system)
n = power_system.n
m = power_system.m

def object_function(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    cost = 0

    for i, gen in enumerate(power_system.generators):
        cost += gen.cp2 * p[i] * p[i] + gen.cp1 * p[i] + gen.cp0
        cost += gen.cq2 * q[i] * q[i] + gen.cq1 * q[i] + gen.cq0
    
    return cost

def equality_constraints(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    Y = power_system.Y

    bp = np.zeros(n)
    bq = np.zeros(n)

    for i, gen in enumerate(power_system.generators):
        bp[gen.node] += p[i]
        bq[gen.node] += q[i]
    
    for load in power_system.loads:
        bp[load.node] -= load.p_demand
        bq[load.node] -= load.q_demand
    
    eq = []

    for i in range(n):
        pi = sum(v[i] * v[j] * (Y[i, j].real * np.cos(a[i] - a[j]) + Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n)) - bp[i]
        qi = sum(v[i] * v[j] * (Y[i, j].real * np.sin(a[i] - a[j]) - Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n)) - bq[i]

        eq.append(pi)
        eq.append(qi)
    
    return np.array(eq)

# 变量边界
v_bounds = [(bus['min_v'], bus['max_v']) for bus in power_system.buses]
a_bounds = [(-np.pi, np.pi)] * (n)
p_bounds = [(gen.min_p, gen.max_p) for gen in power_system.generators]
q_bounds = [(gen.min_q, gen.max_q) for gen in power_system.generators]

bounds = v_bounds + a_bounds + p_bounds + q_bounds

# 初始猜测值
initial_guess = np.zeros(n+n+m+m)

# 定义等式约束
eq_cons = {'type': 'eq', 'fun': lambda x: equality_constraints(x)}

# 求解最优潮流
result = minimize(object_function, initial_guess, method='SLSQP', bounds=bounds, constraints=[eq_cons])

# 输出结果
print("Optimal solution found:")
print("Voltage magnitudes:", result.x[:n])
print("Phase angles:", result.x[n:n+n])
print("Active power generators:", result.x[n+n:n+n+m])
print("Reactive power generators:", result.x[n+n+m:n+n+m+m])
print("Total cost:", result.fun)
"""

prompt = """
## 背景
上面是一段标准、正确的求解最优潮流问题的代码
## 任务
假设用户在询问最优潮流计算代码的上下界和初始值如何确定，而大模型则先给出思路再给出正确的代码片段。
请你帮我随机选择一种主题，根据此产生对话，进而生成一些 sft 数据。
## 代码
```python
[MASK:code]
```
## 格式
<message>
{
    "message": [
        {"content": ..., "role": "user"},
        {"content": ..., "role": "assistant"}
    ]
}
</message>
"""

prompt = prompt.replace('[MASK:code]', code)

from response.qwen import get_response
from utils.parse_output import parse_block, parse_tag
from utils.reader import read_jsonl

import json

for _ in range(30):
    r = get_response(prompt, model='qwen-max', temperature=0.9)

    r = parse_tag(r, 'message')

    print(r)

    try:
        # 将记录追加到 record.jsonl 文件
        r_cleaned = json.dumps(json.loads(r), ensure_ascii=False)
        with open("code_generate_0324_v4.jsonl", "a", encoding="utf-8") as f:
            f.write(r_cleaned + "\n")
    except:
        print('failed')
        continue
