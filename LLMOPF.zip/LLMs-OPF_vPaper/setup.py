from setuptools import setup, find_packages

setup(
    name="llmopf",
    version="3",
    packages=find_packages(),
    package_data={
        'llmopf': ['*.jsonl', '*.csv'],  # 包含数据文件
    },
)