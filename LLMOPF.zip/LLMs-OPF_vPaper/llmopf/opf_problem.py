get_data = """
电网的信息存储在名字叫 ps 的 PowerSystem 类的实例中， ps 的定义如下：
from llmopf.get_powersystem import get_power_system
ps = get_power_system()
"""

data_struct = """
电网模型数据结构说明：

1. 发电机类(Generator):
- node: 所连节点编号
- cost_coefficients: 发电成本系数(a,b,c)
- active_power_limits: 有功功率限值[mW] (最小,最大)
- reactive_power_limits: 无功功率限值[mVar] (最小,最大)

2. 负荷类(Load): 
- node: 所连节点编号
- power_demand: 功率需求(P,Q) [mW,mVar]

3. 静态电源类(StaticGenerator):
- node: 所连节点编号  
- power_injection: 功率注入(P,Q) [mW,mVar]

4. 母线类(Bus):
- node: 节点编号
- min_voltage: 最低允许电压[kV]
- max_voltage: 最高允许电压[kV]  
- nominal_voltage: 标称电压[kV]

5. 电力系统类(PowerSystem):
- num_nodes: 总节点数
- num_generators: 发电机数量
- num_loads: 负荷数量  
- admittance_matrix: 导纳矩阵
- generators: 发电机列表[List[Generator]]
- loads: 负荷列表[List[Load]]
- static_generators: 静态电源列表[List[StaticGenerator]] 
- buses: 母线列表[List[Bus]]

注：所有功率单位mW(毫瓦)/mVar(毫乏)，电压单位kV(千伏)
"""

opf_object = """
"""

groundtruth_case33_obj4 = """
fun: 17491.852941161902, v: [252.071939   249.84725576 252.03706987 248.5269002  253.        ], a: [-2.00686521 -2.05942629 -2.05328375 -2.04877398 -1.98833309], p: [ 40.         364.39509804 600.        ], q: [ 30.         243.81504505  89.6262603 ]
"""