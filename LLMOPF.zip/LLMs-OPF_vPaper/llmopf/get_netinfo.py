from llmopf.response.base import get_response
from llmopf.utils.parse_output import parse_tag, parse_block
from llmopf.config import get_para

prompt_describe = """
## 任务
找出下面代码中相应的变量/成员变量
## 代码
[MASK:code]
## 格式
请将最后的回复使用 <reply> ... </reply> 标识
<reply>
**注意，如果是成员变量，请标注 self. 字样**

电网的节点数量、发电机数量：
电网的导纳矩阵：

电网的发电机 i 所在节点位置、有功功率约束、无功功率约束：

电网的负荷 i 所在节点位置、有功功率、无功功率：

电网的静态发电机 i 所在节点位置、注入的有功功率、无功功率：

电网节点 i 的约束，电压幅值最小值、最大值、标准值（如果有）：

检查电压的单位的平方是不是和功率单位对的上（kV 对 mW 和 mVar，V 对 W 和 Var）：
</reply>
## 你的回复
"""

prompt_getps = """
## 任务
分析下面代码中，写出获取储存电网信息的实例/变量的调用片段
## 代码
[MASK:code]
## 代码文件相对位置
[MASK:file]
## 格式
```python
from ... import ...
ps = ... # 电网的信息存储在名字叫 ps 的实例/变量中
```
## 你的回复
"""

def get_net_info(net_file='llmopf/powernet.py'):
    with open(net_file, 'r') as f:
        net_code = f.read()

        prompt = prompt_describe.replace('[MASK:code]', net_code)
        response = get_response(prompt)
        describe = parse_tag(response, 'reply')
        describe = f'---\nps 的数据结构的描述：\n{describe}'

        prompt = prompt_getps.replace('[MASK:code]', net_code).replace('[MASK:file]', net_file)
        response = get_response(prompt)
        getps = parse_block(response, 'python')
        getps = f'电网的信息存储在名字叫 ps 的实例\变量中， ps 的获取方式如下：\n{getps}'

        obj = '---\n' + get_para('object')

        return getps + describe + obj
    
    return ''


