from llmopf.run import execute
from llmopf.origin_info import origin_info_case5_obj1, groundtruth_case5_obj1
from llmopf.origin_info import origin_info_case9_obj2, groundtruth_case9_obj2
from llmopf.utils.compare_fun_values import compare_fun_values

def evaluate(case='case5obj1', n=50):
    acc = 0
    t = 0
    fun = 0

    if ('case5obj1' in case):
        groundtruth = groundtruth_case5_obj1
        origin_info = origin_info_case5_obj1
    else:
        groundtruth = groundtruth_case9_obj2
        origin_info = origin_info_case9_obj2
        origin_info += '具体来说，希望节点的电压尽量在参考电压附近。\n'

    for i in range(n):
        result, tim = execute(origin_info)

        if ('fun' in result):
            fun += 1
        acc += compare_fun_values(result, groundtruth)
        t += tim
        # except:
        #     continue

        print(f'round: {i+1}, acc: {acc / (i+1)}, fun {fun}')

    print(acc / n)
    return acc / n, t, fun / n