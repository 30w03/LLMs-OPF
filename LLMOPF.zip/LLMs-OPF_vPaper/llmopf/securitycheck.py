from llmopf.actions.executecode import execute_code
from llmopf.config import get_opfcode, set_para
from llmopf.utils.parse_str import extract_result_values

def security_check(start_time, end_time):
    code = get_opfcode()
    res_data = []

    for t in range(start_time, end_time):
        set_para('time_slot', t)

        result = execute_code(code)

        if ('error' in result):
            print(f'time slot {t} fail')
        else:
            try:
                res = extract_result_values(result)
                res_data.append(res)
            except:
                print(f'time slot {t} fail')
    
    return res_data