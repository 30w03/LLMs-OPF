import dashscope

lyn_api_key = 'sk-02d1d8d06cd54a189972dcb1aae2f657'

model_qwen_max = 'qwen-max'

def get_response(prompt, model="qwen-plus", temperature=0.7, top_p=0.8):
    messages = [{'role': 'user', 'content': prompt}]

    response = dashscope.Generation.call(
        api_key=lyn_api_key,
        model=model,
        messages=messages,
        top_p=top_p,
        temperature=temperature,
        result_format='message',
        enable_thinking=False,
        seed=377
    )
    try:
        return response.output.choices[0].message.content
    except:
        print(response)
        return "no reply"