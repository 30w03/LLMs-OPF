from llmopf.response.qwen import get_response as ask_qwen
from llmopf.utils.sft_format import make_message
from llmopf.config import get_para
import json

def get_response(prompt):
    text = ask_qwen(prompt, model=get_para('LLM'), temperature=get_para('temperature'))
    m = make_message(prompt, text)
    # 将记录追加到 record.jsonl 文件
    with open(get_para('LLM-response-record'), "a", encoding="utf-8") as f:
        f.write(json.dumps(m, ensure_ascii=False) + "\n")
    return text