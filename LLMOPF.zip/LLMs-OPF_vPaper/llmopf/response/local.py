import requests
import json
import os

from llmopf.utils.sft_format import make_message

# 服务器配置
URL = "http://10.8.32.14:34191/v1/chat/completions"
headers = {
    "Content-Type": "application/json"
}

def get_response(prompt, temperature=0):
    # 构造请求数据
    data = {
        "model": "Qwen/Qwen2.5-7B-Instruct",
        "messages": [
            {"role": "system", "content": "你是一个助手。"},
            {"role": "user", "content": prompt}
        ],
        "temperature": temperature,
        "top_p": 0.8
    }

    # 发送请求
    resp = requests.post(URL, headers=headers, json=data, stream=True)
    text = resp.json()['choices'][0]['message']['content']

    # # 构造 JSON 记录
    # record = make_message(prompt, text)

    # # 将记录追加到 record.jsonl 文件
    # with open("record_0316.jsonl", "a", encoding="utf-8") as f:
    #     f.write(json.dumps(record, ensure_ascii=False) + "\n")

    return text