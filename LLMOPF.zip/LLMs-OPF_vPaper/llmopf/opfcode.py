import time

from llmopf.actions.action import execute_action
from llmopf.response.base import get_response
from llmopf.actions.executecode import execute_code
from llmopf.utils.parse_output import parse_tag

action1_task = """
根据下面信息，总结出调用变量 ps 的代码
"""

action1_hint = """
```python
...
ps = ...
```
"""

action1 = {
    'tag': 'write_code',
    'task': action1_task,
    'hint': action1_hint,
    'state_indexes': [0]
}

action2_task = """
请你根据电网的信息，确定最优潮流问题的求解变量 x 的组成
"""
action2_hint = """
```python
# 求解变量 x 的组成如下，保留已有注释
v = x[...:...] # 节点幅值
a = x[...:...] # 节点相角
p = x[...:...] # 发电机有功功率
q = x[...:...] # 发电机无功功率
```
"""

action2 = {
    'tag': 'write_code',
    'task': action2_task,
    'hint': action2_hint,
    'state_indexes': [0, 1]
}

action3_task = """
写出最优潮流问题的目标函数
"""

action3_hint = """
```python
def object_function(x):
    return ...
```
"""

action3 = {
    'tag': 'write_code',
    'task': action3_task,
    'hint': action3_hint,
    'state_indexes': [0, 1, 2]
}

action4_task = """
根据给出的信息写出计算每个节点发电机功率减去负荷功率的函数
"""

action4_hint = """
```python
def calc_node_power(x):
    p = x[...:...] # 从 x 提取发电机的有功功率
    q = x[...:...] # 从 x 提取发电机的无功功率
    return p_list, q_list
```
"""

action4 = {
    'tag': 'write_code',
    'task': action4_task,
    'hint': action4_hint,
    'state_indexes': [0, 1, 2]
}

action5_task = """
根据潮流方程计算最优潮流的等式约束
公式如下：
sum(v[i] * v[j] * (Y[i, j].real * np.cos(a[i] - a[j]) + Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n)) - bp[i] = 0
sum(v[i] * v[j] * (Y[i, j].real * np.sin(a[i] - a[j]) - Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n)) - bq[i] = 0
bp[i], bq[i] 是每个节点的发电机功率与负荷功率的差
"""

action5_hint = """
```python
def equality_constraints(x):
    return ... # list
```
"""

action5 = {
    'tag': 'write_code',
    'task': action5_task,
    'hint': action5_hint,
    'state_indexes': [0, 1, 2, 4]
}

action6_task = """
写出求解变量每一个元素的上下界，注意给出的单位，求解变量的初值
"""

action6_hint = """
```python
...
bounds = [...]
x0 = ...
```
"""

action6 = {
    'tag': 'write_code',
    'task': action6_task,
    'hint': action6_hint,
    'state_indexes': [0, 1, 2]
}

action7_task = """
根据下面信息，整理出完整的求解最优潮流的代码，不需要增加额外功能
该代码需要调用求解器，使用内点法，输出潮流的结果，需要有最优值和最优解
"""

action7_hint = """
```python
...
result_str = 'fun: ..., v: ..., a: ..., p: ..., q: ...'

print(result_str)
```
"""

action7 = {
    'tag': 'write_code',
    'task': action7_task,
    'hint': action7_hint,
    'state_indexes': [1, 2, 3, 4, 5, 6]
}

action_list = [action1, action2, action3, action4, action5, action6, action7]

def opfcode(origin_info):
    state_list = [origin_info]

    tim = time.time()
    start_time = tim

    for act in action_list:
        state_list.append(execute_action(act, state_list))
        print(f'state {len(state_list) - 1} use {time.time() - tim}s')
        # print(state_list[-1][:min(10, len(state_list[-1]))])
        print(state_list[-1])
        tim = time.time()

    # print(state_list[-1])

    return state_list[-1], tim - start_time

code_eco = """
from lmaef.powernet import get_ps
from scipy.optimize import minimize
import numpy as np

ps = get_ps()

load_p_sum = 0

for load in ps.loads:
    load_p_sum += load.p_demand
print("总负荷功率:", load_p_sum)

sgen_p_sum = 0

for sgen in ps.sgens:
    sgen_p_sum += sgen.p_inject
print("总静态发电机功率:", sgen_p_sum)

# 目标函数
def object_function(x):
    v = x[:ps.n]

    cost = 0

    for i in range(ps.n):
        cost += (v[i] - ps.buses[i]['vn_kv']) ** 2

    return cost

# 计算节点功率
def calc_node_power(x):
    p = x[2 * ps.n:2 * ps.n + ps.m]  # 从 x 提取发电机的有功功率
    q = x[2 * ps.n + ps.m:]          # 从 x 提取发电机的无功功率
    
    # 初始化结果列表，用于存储每个节点的净有功功率和净无功功率
    net_p = [0] * ps.n
    net_q = [0] * ps.n
    
    # 处理动态发电机
    for i in range(ps.m):
        gen = ps.generators[i]
        node = gen.node
        net_p[node] += p[i]
        net_q[node] += q[i]
    
    # 处理静态发电机
    for sgen in ps.sgens:
        node = sgen.node
        net_p[node] += sgen.p_inject
        net_q[node] += sgen.q_inject
    
    # 减去负荷功率
    for load in ps.loads:
        node = load.node
        net_p[node] -= load.p_demand
        net_q[node] -= load.q_demand
    
    return net_p, net_q

# 等式约束
def equality_constraints(x):
    v = x[:ps.n]  # 节点幅值
    a = x[ps.n:2 * ps.n]  # 节点相角
    eq_cons = []
    
    node_p, node_q = calc_node_power(x)
    
    for i in range(ps.n):
        bp_i = node_p[i]
        bq_i = node_q[i]
        
        eq_cons.append(
            sum(v[i] * v[j] * (ps.Y[i, j].real * np.cos(a[i] - a[j]) + ps.Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(ps.n)) - bp_i
        )
        eq_cons.append(
            sum(v[i] * v[j] * (ps.Y[i, j].real * np.sin(a[i] - a[j]) - ps.Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(ps.n)) - bq_i
        )
    
    return eq_cons

# 定义求解变量的上下界
bounds = []
for i in range(ps.n):
    bounds.append((ps.buses[i]['min_v'], ps.buses[i]['max_v']))  # 节点幅值的上下界
for i in range(ps.n):
    bounds.append((-3.14, 3.14))  # 节点相角的上下界
for gen in ps.generators:
    bounds.append((gen.min_p, gen.max_p))  # 发电机有功功率的上下界
for gen in ps.generators:
    bounds.append((gen.min_q, gen.max_q))  # 发电机无功功率的上下界

# 初始值 x0
x0 = []
for i in range(ps.n):
    x0.append((ps.buses[i]['min_v'] + ps.buses[i]['max_v']) / 2)  # 节点幅值的初始值
for i in range(ps.n):
    x0.append(0)  # 节点相角的初始值设为0
for gen in ps.generators:
    x0.append((gen.min_p + gen.max_p) / 2)  # 发电机有功功率的初始值
for gen in ps.generators:
    x0.append((gen.min_q + gen.max_q) / 2)  # 发电机无功功率的初始值

# 使用内点法求解
res = minimize(object_function, x0, method='SLSQP', bounds=bounds, constraints={'type': 'eq', 'fun': equality_constraints})

# 输出结果
if res.success:
    result_str = f"fun: {res.fun}, v: {res.x[:ps.n]}, a: {res.x[ps.n:2*ps.n]}, p: {res.x[2*ps.n:2*ps.n+ps.m]}, q: {res.x[2*ps.n+ps.m:]}"
else:
    result_str = "Optimization failed."

print(result_str)
"""