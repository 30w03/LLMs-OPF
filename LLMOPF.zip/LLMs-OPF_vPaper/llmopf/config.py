# config.py

class _GlobalConfig:
    def __init__(self):
        self._obj_dict = {
            'economy':  '该电网的运行目的是最小化发电机发电成本', 
            'voltage':  '该电网的运行目标是保持电压稳定，具体来说，希望节点的电压尽量在参考电压附近', 
            # 'capacity': '该电网的运行目的是确保线路容量安全'
        }

        self._params = {
            'object': 'voltage',
            'case': 'case5',
            'time_slot': 0,
            'LLM': 'qwen3-32b',
            'temperature': 0,
            'method': 'lmaef',
            'result-record': './record/result/tmp.jsonl',
            'experiment': 'tmp',
            'LLM-response-record': './record/record_0704_vpaper.jsonl',
            'opf-code-record': './record/opfcode/opfcode.py'
        }
    
    def set_para(self, key, value):
        self._params[key] = value
    
    def get_para(self, key, default=None):
        return self._params.get(key, default)
    
    def set_opfcode(self, code):
        with open(self._params['opf-code-record'], 'w') as f:
            f.write(code)
    
    def get_opfcode(self):
        with open(self._params['opf-code-record'], 'r') as f:
            text = f.read()
        
        return text
    
    def get_object(self):
        object_dict = self._obj_dict

        if object_dict.get(self.get_para('object')) is None:
            raise KeyError('全局参数 object 设置异常，没用此键值')

        return object_dict.get(self.get_para('object'))

# 单例实例
_config = _GlobalConfig()

def set_para(key, value):
    return _config.set_para(key, value)

def get_para(key, default=None):
    return _config.get_para(key, default)

def set_opfcode(code):
    return _config.set_opfcode(code)

def get_opfcode():
    return _config.get_opfcode()

def get_object():
    return _config.get_object()