import re

def compare_fun_values(str1, str2):
    """
    比较两个字符串中fun值的整数部分是否相等
    
    参数:
        str1 (str): 第一个字符串
        str2 (str): 第二个字符串
        
    返回:
        bool: 如果fun值的整数部分相等返回True，否则返回False
    """

    if ('fun' not in str1):
        return 0
    
    str1 = str1.split('fun')[-1]
    
    numbers1 = re.findall(r"\d+\.?\d*", str1)  # 匹配整数和小数
    numbers2 = re.findall(r"\d+\.?\d*", str2)  # 匹配整数和小数

    if (len(numbers1) < 1):
        return 0
    else:
        if (abs(float(numbers1[0]) - float(numbers2[0])) < 1):
            return 1
        else:
            return 0