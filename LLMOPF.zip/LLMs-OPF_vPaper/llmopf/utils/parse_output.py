import json

def parse_output(response):
    if ('```json' in response):
        response = response.split('```json')[1]
        response = response.split('```')[0]
    response_json = json.loads(response)
    return response_json['output']

def parse_code(response):
    if ('```python' in response):
        response = response.split('```python')[1]
        response = response.split('```')[0]
    return response

def parse_block(response, block_name):
    if (f'```{block_name}' in response):
        response = response.split(f'```{block_name}')[1]
        response = response.split('```',)[0]
        return response
    else:
        return f'not block named {block_name}!'

def parse_tag(response, tag_name):
    if (f'<{tag_name}>' in response):
        response = response.split(f'<{tag_name}>')[1]
        response = response.split(f'</{tag_name}>')[0]
        return response
    else:
        # print(response)
        return f'not block named {tag_name}!'