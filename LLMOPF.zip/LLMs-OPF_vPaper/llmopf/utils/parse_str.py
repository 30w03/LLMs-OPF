import re
import numpy as np

def extract_numbers(line):
        """专门用于电力系统数据的数字提取函数"""
        # 移除文本描述部分
        if ':' in line:
            line = line.split(':', 1)[1]
        
        # 处理括号内容
        line = re.sub(r'\([^)]*\)', lambda m: m.group(0).replace(' ', ','), line)
        
        # 提取所有数字（包括科学计数法）
        numbers = []
        for match in re.finditer(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?', line):
            num_str = match.group(0)
            # 处理可能的分隔符问题
            if num_str.startswith(('+', '-')) and (',' in num_str or ' ' in num_str):
                continue  # 可能是分割错误
            numbers.append(float(num_str))
        
        return numbers

def extract_result_values(s: str):
    s = s.split(':')
    result = {}
    result['fun'] = extract_numbers(s[1])
    result['v'] = extract_numbers(s[2])
    result['a'] = extract_numbers(s[3])
    result['p'] = extract_numbers(s[4])
    result['q'] = extract_numbers(s[5])
    
    return result