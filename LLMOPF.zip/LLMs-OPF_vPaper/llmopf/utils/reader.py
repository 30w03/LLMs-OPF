import json

def read_jsonl(file_path):
    """
    读取 JSON Lines 文件并返回一个包含所有 JSON 对象的列表。

    :param file_path: JSON Lines 文件的路径
    :return: 包含所有 JSON 对象的列表
    """
    data = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    # 解析每一行的 JSON 数据
                    json_obj = json.loads(line.strip())
                    data.append(json_obj)
                except json.JSONDecodeError as e:
                    print(f"解析 JSON 失败：{e}，行内容：{line.strip()}")
    except FileNotFoundError:
        print(f"文件未找到：{file_path}")
    except Exception as e:
        print(f"读取文件失败：{e}")
    return data
