def make_message(prompt, responce):
    # 构造 JSON 记录
    record = {
        "system": "你是一个助手。",
        "messages": [
            {"content": prompt, "role": "user"},
            {"content": responce, "role": "assistant"}
        ]
    }

    return record