import json
import os
from pathlib import Path
from datetime import datetime

from llmopf.config import get_para

def make_experiment_record(result):
    current_time = datetime.now().strftime("%m-%d-%H-%M")  # 例如 "07-19-14-30" 表示7月19日14点30分

    # 构造 JSON 记录
    record = {
        "date": current_time, # month-day-hour-minute
        "experiment": get_para('experiment'),
        "case": get_para('case'),
        "object": get_para('object'),
        "method": get_para('method'),
        "LLM": get_para('LLM'),
        "temperature": get_para('temperature'),
        "result": result
    }

    return record

def write_record(result):
    """
    写入记录到文件，如果路径不存在则自动创建
    
    Args:
        result: 要写入的记录（可被json序列化的对象）
    """
    record = make_experiment_record(result)

    try:
        # 获取文件路径
        file_path = get_para('result-record')
        
        # 确保路径存在
        file_dir = os.path.dirname(file_path)
        if file_dir:  # 如果路径包含目录部分
            Path(file_dir).mkdir(parents=True, exist_ok=True)
        
        # 写入文件
        with open(file_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            
    except (TypeError, ValueError) as e:
        print(f"记录序列化失败: {e}")
    except PermissionError:
        print(f"无权限写入文件: {file_path}")
    except Exception as e:
        print(f"写入记录时发生未知错误: {e}")