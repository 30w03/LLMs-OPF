import random
import re
import os

from llmopf.response.qwen import get_response

def add_semantic_noise(t: str, noise_level: float = 0.3) -> str:
    """
    为文本添加语义保持的噪声
    
    参数:
        t: 原始文本
        noise_level: 噪声强度 (0-1)，控制文本变化的程度
    
    返回:
        添加噪声后的文本
    """
    # 根据噪声强度选择不同的提示词
    if noise_level < 0.3:
        prompt = f"请用另一种简单的表达方式重写以下文本，保持原意不变，参考噪声系数{noise_level}:\n{t}"
    elif noise_level < 0.6:
        prompt = f"请用不同的措辞改写以下文本，可以稍微扩展或简化，但保持核心意思不变，参考噪声系数{noise_level}:\n{t}"
    else:
        prompt = f"请对以下文本进行较大的改写，可以使用不同的表达方式、例子或结构，但不要改变原始含义，参考噪声系数{noise_level}:\n{t}"
    
    # 调用大模型获取改写后的文本
    modified_text = get_response(prompt, model='qwen-turbo')
    
    # 可选：有时大模型会在回复中添加额外内容，这里做简单清理
    modified_text = modified_text.strip()
    if modified_text.startswith('"') and modified_text.endswith('"'):
        modified_text = modified_text[1:-1]
    
    return modified_text

def generate_text_set(t: str, path: str, num_files: int = 50, 
                     noise_level_range: tuple = (0.1, 0.9)) -> None:
    """
    生成带语义噪声的文本集合并保存到文件
    
    参数:
        t: 原始文本
        path: 输出目录路径
        num_files: 生成文件数量 (默认50)
        noise_level_range: 噪声强度范围 (min, max)
    """
    # 确保输出目录存在
    os.makedirs(path, exist_ok=True)
    
    for i in range(1, num_files + 1):
        # 在给定范围内随机选择噪声强度
        noise_level = random.uniform(*noise_level_range)
        
        # 生成带噪声文本
        noisy_text = add_semantic_noise(t, noise_level=noise_level)
        
        # 写入文件
        filename = os.path.join(path, f"noise{i}.txt")
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(noisy_text)
        
        # 打印进度
        if (i % 10) == 0:
            print(f"已生成 {i}/{num_files} 个文件")

# # 使用示例
# if __name__ == "__main__":
#     original_text = """最优潮流问题是电力系统经济调度的重要工具，
#                     它通过优化发电机出力来最小化运行成本。"""
    
#     output_dir = "./noisy_texts"  # 输出目录
#     generate_text_set(original_text, output_dir)