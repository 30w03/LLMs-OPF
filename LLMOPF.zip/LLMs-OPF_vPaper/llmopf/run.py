import time

from llmopf.actions.action import execute_action
from llmopf.response.base import get_response
from llmopf.actions.executecode import execute_code
from llmopf.utils.parse_output import parse_tag, parse_code
from llmopf.config import set_opfcode

action1_task = """
根据下面信息，总结出调用变量 ps 的代码
"""

action1_hint = """
```python
...
ps = ...
```
"""

action1 = {
    'tag': 'write_code',
    'task': action1_task,
    'hint': action1_hint,
    'state_indexes': [0]
}

action2_task = """
请你根据电网的信息，确定最优潮流问题的求解变量 x 的组成
"""
action2_hint = """
```python
# 求解变量 x 的组成如下，保留已有注释
v = x[...:...] # 节点幅值
a = x[...:...] # 节点相角
p = x[...:...] # 发电机有功功率
q = x[...:...] # 发电机无功功率
```
"""

action2 = {
    'tag': 'write_code',
    'task': action2_task,
    'hint': action2_hint,
    'state_indexes': [0]
}

action3_task = """
写出最优潮流问题的目标函数
"""

action3_hint = """
```python
def object_function(x):
    return ...
```
"""

action3 = {
    'tag': 'write_code',
    'task': action3_task,
    'hint': action3_hint,
    'state_indexes': [0, 2]
}

action4_task = """
根据潮流方程计算最优潮流的等式约束
公式如下：
sum(v[i] * v[j] * (Y[i, j].real * np.cos(a[i] - a[j]) + Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n)) - bp[i] = 0
sum(v[i] * v[j] * (Y[i, j].real * np.sin(a[i] - a[j]) - Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n)) - bq[i] = 0
bp[i], bq[i] 是每个节点的发电机功率与负荷功率的差
"""

action4_hint = """
```python
def equality_constraints(x):
    # 计算 bp, bq
    ...
    # 潮流公式
    return ... # list
```
"""

action4 = {
    'tag': 'write_code',
    'task': action4_task,
    'hint': action4_hint,
    'state_indexes': [0, 2]
}

action5_task = """
写出求解变量每一个元素的上下界，注意给出的单位，求解变量的初值
"""

action5_hint = """
```python
...
bounds = [...]
x0 = ...
```
"""

action5 = {
    'tag': 'write_code',
    'task': action5_task,
    'hint': action5_hint,
    'state_indexes': [0, 2]
}

action6_task = """
根据下面信息，整理出完整的求解最优潮流的代码，不需要增加额外功能
该代码需要调用求解器，使用内点法，输出潮流的结果，需要有最优值和最优解
"""

action6_hint = """
```python
...
result_str = 'fun: ..., v: ..., a: ..., p: ..., q: ...'

print(result_str)
```
"""

action6 = {
    'tag': 'write_code',
    'task': action6_task,
    'hint': action6_hint,
    'state_indexes': [1, 2, 3, 4, 5]
}

action7 = {
    'tag': 'execute_code',
    'state_index': 6
}

action_list = [action1, action2, action3, action4, action5, action6, action7]

def execute(origin_info):
    state_list = [origin_info]

    tim = time.time()
    start_time = tim

    for act in action_list:
        state_list.append(execute_action(act, state_list))
        print(f'state {len(state_list) - 1} use {time.time() - tim}s')
        # print(state_list[-1][:min(10, len(state_list[-1]))])
        print(state_list[-1])
        tim = time.time()

    # print(state_list[-1])
    set_opfcode(parse_code(state_list[-2]))
    
    return state_list[-1], tim - start_time

prompt = """
## 背景
我需要你结合相关信息，写出代码
## 信息
[MASK:info]
## 你的回复
"""

def execute_direct(origin_info):
    start_time = time.time()

    p = prompt.replace('[MASK:info]', origin_info)
    r = get_response(p)

    print(r)

    o = execute_code(r)
    print(o)

    return o, time.time() - start_time

prompt = """
## 背景
我需要你结合相关信息和提示写出完整的可执行的代码
## 信息
[MASK:info]
## 思维链提示
写出定义 ps 的代码
然后确定最优潮流问题的求解变量 x 的组成
然后写出最优潮流问题的目标函数
然后写出计算每个节点发电机功率减去负荷功率的函数
然后根据潮流方程计算最优潮流的等式约束
公式如下：
sum(v[i] * v[j] * (Y[i, j].real * np.cos(a[i] - a[j]) + Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n)) - bp[i] = 0
sum(v[i] * v[j] * (Y[i, j].real * np.sin(a[i] - a[j]) - Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n)) - bq[i] = 0
bp[i], bq[i] 是每个节点的发电机功率与负荷功率的差
然后求解变量每一个元素的上下界，注意给出的单位，求解变量的初值
然后整理出完整的求解最优潮流的代码，不需要增加额外功能，该代码需要调用求解器，使用内点法，输出潮流的结果，需要有最优值和最优解
代码最后的输出格式：
```python
...
result_str = 'fun: ..., v: ..., a: ..., p: ..., q: ...'

print(result_str)
```
## 你的回复
"""

def execute_cot(origin_info):
    tim = time.time()

    p = prompt.replace('[MASK:info]', origin_info)

    r = get_response(p)
    print(r)

    o = execute_code(r)

    return o, time.time() - tim

prompt_react = """

"""

def execute_react(origin_info):
    tim = time.time()

    p = prompt_react.replace('[MASK:info]', origin_info)

    for step in range(1, 8):
        r = get_response(p)

        cot = parse_tag(r, 'think')
        act = parse_tag(r, 'action')
        
