import importlib.util
import importlib

import io
import sys

from llmopf.utils.parse_output import parse_block

def run_code_directly(code, local_imports=None):
    """
    在当前 Python 进程中直接运行 Python 代码，并获取其输出。

    :param code: 要运行的 Python 代码字符串
    :param local_imports: 一个字典，键是模块名称，值是需要动态加载的本地模块路径
    :return: 代码的输出内容（字符串）或最后一条表达式的结果
    """
    # 创建一个模块名称
    module_name = "dynamic_code_module"
    
    # 使用 importlib 将代码字符串编译为模块
    spec = importlib.util.spec_from_loader(module_name, loader=None)
    module = importlib.util.module_from_spec(spec)

    # 动态加载本地模块并添加到 module.__dict__
    if local_imports is not None:
        for module_name, module_path in local_imports.items():
            try:
                # 动态加载模块
                spec = importlib.util.spec_from_file_location(module_name, module_path)
                loaded_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(loaded_module)
                # 将加载的模块添加到 module.__dict__
                module.__dict__[module_name] = loaded_module
            except Exception as e:
                print(f"无法加载模块 {module_name}：{e}")
                return None, f"无法加载模块 {module_name}：{e}"
    
    # 重定向标准输出以捕获打印内容
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    
    try:
        # 执行代码
        exec(code, module.__dict__)
        
        # 获取捕获的输出
        output = sys.stdout.getvalue()
        
        # 恢复标准输出
        sys.stdout = old_stdout
        
        # 返回捕获的输出
        return output, ''
    except Exception as e:
        # 恢复标准输出
        sys.stdout = old_stdout
        
        return None, f'error: {e}'
    except:
        sys.stdout = old_stdout
        
        return None, 'error: execute \'exit()\''

def execute_code(code):
    if ('```python' in code):
        code = parse_block(code, 'python')
    output, error = run_code_directly(code)

    if (output is None):
        return str(error)
    else:
        return output