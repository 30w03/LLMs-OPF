from llmopf.response.base import get_response
from llmopf.utils.parse_output import parse_tag, parse_code

prompt_write_code = """
## 背景
我需要你按照下面要求，结合相关信息，写出符合给定格式的代码
## 要求
[MASK:task]
## 信息
[MASK:info]
## 格式
<think>
你的思考过程
</think>
<code>
[MASK:hint]
</code>
## 回复
"""

def write_code(task, hint, info):
    p = prompt_write_code.replace('[MASK:task]', task).replace('[MASK:info]', info).replace('[MASK:hint]', hint)

    r = get_response(p)
    r = parse_code(r)

    return r
