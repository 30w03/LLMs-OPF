from llmopf.actions.writecode import write_code
from llmopf.actions.executecode import execute_code

def action_execute_code(action, state_list):
    code = state_list[action['state_index']]
    return execute_code(code)

def action_write_code(action, state_list, record=None):
    task = action['task']
    hint = action['hint']
    info = ''
    for i in action['state_indexes']:
        info = info + state_list[i]
    return write_code(task, hint, info)

def execute_action(action, state_list):
    if (action['tag'] == 'execute_code'):
        return action_execute_code(action, state_list)
    elif (action['tag'] == 'write_code'):
        return action_write_code(action, state_list)
    else:
        return ''