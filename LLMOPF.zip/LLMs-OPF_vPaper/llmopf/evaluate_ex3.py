"""
实验三：时序测试
"""

from llmopf.opfcode import opfcode, code_eco
from llmopf.actions.executecode import execute_code
import llmopf.origin_info

def evaluate(args):
    acc = 0
    t = 0
    fun = 0

    net_info = llmopf.origin_info.net_info
    
    if (args.object == 'economy'):
        object_info = llmopf.origin_info.object_info_economy
    elif (args.object == 'reliability'):
        object_info = llmopf.origin_info.object_info_reliability
    else:
        ... # 其他目标函数
    
    origin_info = net_info + object_info

    # opf_code, tim = opfcode(origin_info)
    opf_code = code_eco

    print(opf_code)

    for i in range(args.time_slot_num):
        print(f'ps = get_ps(\'{args.case}\', {i})')
        current_code = opf_code.replace('ps = get_ps()', f'ps = get_ps(\'{args.case}\', {i})')

        opf_result = execute_code(current_code)

        print(opf_result)