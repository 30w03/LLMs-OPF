import pandapower.networks as pn
import pandapower as ppower
import numpy as np
from scipy.optimize import minimize

from llmopf.ex1_lmaef.powernet import get_ps
from llmopf.config import get_para

# case = get_para('case')
# obj = get_para('object')

# print(f'goundtruth solving the problem with case={case}, object={obj}')

power_system = get_ps()
# print(power_system)
n = power_system.n
m = power_system.m

def object_function_voltage(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    cost = 0

    for i in range(n):
        cost += (v[i] - power_system.buses[i]['vn_kv']) ** 2

    return cost

def object_function_economy(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    cost = 0

    for i in range(m):
        cp0 = power_system.generators.cp0
        cp1 = power_system.generators.cp1
        cp2 = power_system.generators.cp2
        cost += cp2 * p[i] * p[i] + cp1 * p[i] + cp0

    return cost

obj_dict = {
    'economy': object_function_economy,
    'voltage': object_function_voltage
}

def equality_constraints(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    Y = power_system.Y

    bp = np.zeros(n)
    bq = np.zeros(n)

    for i, gen in enumerate(power_system.generators):
        bp[gen.node] += p[i]
        bq[gen.node] += q[i]
    
    for load in power_system.loads:
        bp[load.node] -= load.p_demand
        bq[load.node] -= load.q_demand
    
    eq = []

    for i in range(n):
        pi = sum(v[i] * v[j] * (Y[i, j].real * np.cos(a[i] - a[j]) + Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n)) - bp[i]
        qi = sum(v[i] * v[j] * (Y[i, j].real * np.sin(a[i] - a[j]) - Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n)) - bq[i]

        eq.append(pi)
        eq.append(qi)
    
    return np.array(eq)

# 变量边界
v_bounds = [(bus['min_v'], bus['max_v']) for bus in power_system.buses]
a_bounds = [(-np.pi, np.pi)] * (n)
p_bounds = [(gen.min_p, gen.max_p) for gen in power_system.generators]
q_bounds = [(gen.min_q, gen.max_q) for gen in power_system.generators]

bounds = v_bounds + a_bounds + p_bounds + q_bounds

# 初始猜测值
initial_guess = np.zeros(n+n+m+m)

# 定义等式约束
eq_cons = {'type': 'eq', 'fun': lambda x: equality_constraints(x)}

# 求解最优潮流
result = minimize(obj_dict.get(get_para('object')), initial_guess, method='SLSQP', bounds=bounds, constraints=[eq_cons])

# print(result)

# # 输出结果
# print("Optimal solution found:")
# print("Voltage magnitudes:", result.x[:n])
# print("Phase angles:", result.x[n:n+n])
# print("Active power generators:", result.x[n+n:n+n+m])
# print("Reactive power generators:", result.x[n+n+m:n+n+m+m])
# print("Total cost:", result.fun)

result_str = f'fun: {result.fun}, v: {result.x[:n]}, a: {result.x[n:n+n]}, p: {result.x[n+n:n+n+m]}, q: {result.x[n+n+m:n+n+m+m]}'

print(result_str)
