from llmopf.actions.executecode import execute_code
from llmopf.config import set_para

from llmopf.ex1_lmaef.groundtruth.groundtruthstr import groundtruth_code

def groundtruth_ex1(case, obj):
    set_para('case', case)
    set_para('object', obj)

    return execute_code(groundtruth_code)