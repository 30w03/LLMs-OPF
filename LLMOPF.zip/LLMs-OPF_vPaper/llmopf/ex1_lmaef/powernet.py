import pandapower.networks as pn
import pandapower as ppower
import numpy as np
import json

from llmopf.config import get_para
from llmopf.netcase.IEEE15 import net_build_IEEE15
from llmopf.netcase.IEEE33 import net_build_IEEE33

eps = 1e-7

class Generator:
    def __init__(self, node, cp0, cp1, cp2, cq0, cq1, cq2, min_p, max_p, min_q, max_q):
        self.node = node  # 发电机所处的节点位置
        self.cp2 = cp2    # 二次成本系数
        self.cp1 = cp1    # 一次成本系数
        self.cp0 = cp0    # 常数成本系数
        self.cq2 = cq2    # 二次成本系数
        self.cq1 = cq1    # 一次成本系数
        self.cq0 = cq0    # 常数成本系数

        self.min_p = min_p
        self.max_p = max_p
        self.min_q = min_q
        self.max_q = max_q

    def __str__(self):
        return (f"Generator(node={self.node}, cp0={self.cp0}, cp1={self.cp1}, cp2={self.cp2}, "
                f"cq0={self.cq0}, cq1={self.cq1}, cq2={self.cq2}, min_p={self.min_p}, max_p={self.max_p}, min_q={self.min_q}, max_q={self.max_q})")

class Load:
    def __init__(self, node, p_demand, q_demand):
        self.node = node          # 负荷所处的节点位置
        self.p_demand = p_demand  # 有功功率需求
        self.q_demand = q_demand  # 无功功率需求

    def __str__(self):
        return f"Load(node={self.node}, p_demand={self.p_demand}, q_demand={self.q_demand})"

class StaticGenerator:
    def __init__(self, node, p_inject, q_inject):
        self.node = node          # 静态发电机所处的节点位置
        self.p_inject = p_inject  # 有功功率注入
        self.q_inject = q_inject  # 无功功率注入

    def __str__(self):
        return f"StaticGenerator(node={self.node}, p_inject={self.p_inject}, q_inject={self.q_inject})"

class Solution:
    def __init__(self, n, m):
        self.generator_p = np.zeros(m)  # 发电机有功功率
        self.generator_q = np.zeros(m)  # 发电机无功功率
        self.v = np.zeros(n)        # 电压幅值
        self.theta = np.zeros(n - 1)    # 电压相角（不含平衡节点)
    
    def __str__(self):
        return f"Solution(gp={self.generator_p}, gq={self.generator_q}, v={self.v}, theta={self.theta})"

class PowerSystem:
    def __init__(self, pandapower_net):
        self.n = len(pandapower_net.bus)
        self.m = len(pandapower_net.gen)

        self.Y = self.calcAdmittanceMatrix(pandapower_net)

        # self.slack_node = slack_node_loc

        self.generators = []
        self.generators_loc = pandapower_net.gen['bus'].values
        self.generators_min_p = pandapower_net.gen['min_p_mw'].values
        self.generators_max_p = pandapower_net.gen['max_p_mw'].values
        self.generators_min_q = pandapower_net.gen['min_q_mvar'].values
        self.generators_max_q = pandapower_net.gen['max_q_mvar'].values

        k = 0

        for i, row in pandapower_net.poly_cost.iterrows():
            if (row['et'] == 'gen'):
                self.generators.append(
                    Generator(
                        self.generators_loc[k],
                        row['cp0_eur'], row['cp1_eur_per_mw'], row['cp2_eur_per_mw2'],
                        row['cq0_eur'], row['cq1_eur_per_mvar'], row['cq2_eur_per_mvar2'],
                        self.generators_min_p[k], self.generators_max_p[k], 
                        self.generators_min_q[k], self.generators_max_q[k]
                    )
                )
                k += 1
        
        self.loads = []
        for i, row in pandapower_net.load.iterrows():
            self.loads.append(Load(row['bus'], row['p_mw'], row['q_mvar']))
        
        self.sgens = []
        for i, row in pandapower_net.sgen.iterrows():
            self.sgens.append(StaticGenerator(row['bus'], row['p_mw'], row['q_mvar']))
        
        self.buses = []
        for i, row in pandapower_net.bus.iterrows():
            self.buses.append({'min_v': int(row['vn_kv'] * row['min_vm_pu']), 'max_v': int(row['vn_kv'] * row['max_vm_pu']), 'vn_kv': int(row['vn_kv'])})
        
        # print(self)

    def calcAdmittanceMatrix(self, pp_net):
        df_bus = pp_net.bus
        Y = np.zeros((self.n, self.n), dtype=complex)
        omega = 2 * np.pi * 60  # 系统频率
        baseMVA = pp_net.sn_mva

        # 计算线路导纳
        for index, row in pp_net.line.iterrows():
            from_bus = row['from_bus']
            to_bus = row['to_bus']
            r = row['r_ohm_per_km'] * row['length_km']
            x = row['x_ohm_per_km'] * row['length_km']
            c = row['c_nf_per_km'] * row['length_km'] * 1e-9  # 转换为法拉
            g = row['g_us_per_km'] * row['length_km'] * 1e-6  # 转换为西门子

            y_series = 1 / (r + 1j * x)
            y_shunt = 1j * omega * c + g

            Y[from_bus, from_bus] += y_series + y_shunt * 0.5
            Y[to_bus, to_bus] += y_series + y_shunt * 0.5
            Y[from_bus, to_bus] -= y_series
            Y[to_bus, from_bus] -= y_series

        # 计算变压器导纳
        for index, row in pp_net.trafo.iterrows():
            hv_bus = row['hv_bus']
            lv_bus = row['lv_bus']
            vn_lv_kv = row['vn_lv_kv']
            vk_percent = row['vk_percent']
            i0_percent = row['i0_percent']
            sn_mva = row['sn_mva']

            zk = (vk_percent * 0.01) * (vn_lv_kv ** 2) / sn_mva
            zk_complex = complex(0, zk)

            ym = (i0_percent * 0.01) * (sn_mva / (vn_lv_kv ** 2))
            ym_complex = complex(ym, 0)

            Y[hv_bus, hv_bus] += (1 / zk_complex) + ym_complex
            Y[lv_bus, lv_bus] += (1 / zk_complex)
            Y[hv_bus, lv_bus] -= (1 / zk_complex)
            Y[lv_bus, hv_bus] -= (1 / zk_complex)

        return Y

    def __str__(self):
        generator_str = [str(g) for g in self.generators]
        load_str = [str(l) for l in self.loads]
        sgen_str = [str(s) for s in self.sgens]
        bus_str = [f'node{i}: {self.buses[i]}' for i in range(self.n)]
        return f"PowerSystem(node_num={self.n}, generator_num={self.m}, load_num={self.k}, admittance_matrix={self.Y}, balance_node={self.slack_node}, generators(mw, mvar)={generator_str}, loads(mw, mvar)={load_str}, sgens(mw, mvar)={sgen_str}, buses(kv)={bus_str})"

def get_ps():
    case = get_para('case')

    if case == 'case5':
        return PowerSystem(pn.case5())
    elif case == 'case9':
        return PowerSystem(pn.case9())
    elif case == 'case14':
        return PowerSystem(pn.case14())
    elif case == 'case15':
        return PowerSystem(net_build_IEEE15())
    elif case == 'case33':
        return PowerSystem(net_build_IEEE33())
    else:
        raise ValueError(f"Unknown case: {case}")