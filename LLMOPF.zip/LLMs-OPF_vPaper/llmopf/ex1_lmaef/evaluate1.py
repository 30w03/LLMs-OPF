"""
实验一：方法性能评估
评测一：同问题求解概率

固定值：
固定 powernet.py
固定 origin_info.py 中的 net_info
固定 temperature=0.7

变量：
电网 case (case5, case9, case14)
目标 obj  (economy, voltage, cap)
大模型 llm (qwen-max, deepseek-v3, qwen3, ...)

接口：
evaluate(n=50) # 从 config 中获取 case, obj, llm 跑 n 次，结果记录在 ./record/result/ex1/evaluate1.jsonl 中
evaluate_batch(case_list, obj_list, llm_list) # 排列组合跑完 evaluate
"""

from llmopf.run import execute, execute_direct, execute_cot
from llmopf.config import set_para, get_para, get_object
from llmopf.utils.experiment_record import write_record

from llmopf.ex1_lmaef.origin_info import net_info
from llmopf.ex1_lmaef.groundtruth.goundtruthtable import groundtruth_ex1

from llmopf.utils.compare_fun_values import compare_fun_values

def evaluate(n=50):
    acc = 0
    t = 0
    fun = 0

    case = get_para('case')
    obj = get_object()
    method = get_para('method')

    origin_info = net_info + obj

    groundtruth = groundtruth_ex1(case, obj)

    for i in range(n):
        if 'lmaef' in method:
            result, tim = execute(origin_info)
        elif 'derict' in method:
            result, tim = execute_direct(origin_info)
        elif 'cot' in method:
            result, tim = execute_cot(origin_info)
        else:
            raise ValueError(f'no method {method}')

        if ('fun' in result):
            fun += 1
            acc += compare_fun_values(result, groundtruth)
        t += tim

        print(f'round: {i+1}, acc: {acc / (i+1)}, fun {fun}')

    # print(acc / n)
    result = f'experiment1 evaluate1: round={n}, acc={acc}, fun={fun}, time={t}'

    set_para('experiment', 'ex1_evaluate1')
    set_para('result-record', './record/result/ex1/evaluate1.jsonl')

    write_record(result)

    return result

def evaluate_batch(case_list, obj_list, llm_list):
    for case in case_list:
        for obj in obj_list:
            for llm in llm_list:
                set_para('case', case)
                set_para('object', obj)
                set_para('LLM', llm)

                evaluate()