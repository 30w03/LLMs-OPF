net_info = """
电网的信息存储在名字叫 ps 的 PowerSystem 类的实例中， ps 的定义如下：
from lmaef.powernet import get_ps
ps = get_ps()
\"\"\"
ps.n # 电网的节点数量
ps.m # 电网的发电机数量
ps.Y # 电网的导纳矩阵
ps.generators # 电网的发电机信息，是 List[Generator] 类型
# Generator 类有下面成员：发电机所在节点位置 node ，发电机功率限制 min_p max_p min_q max_q
ps.loads # 电网负荷信息，是 List[Load] 类型
# Load 类有下面成员：负荷所在节点位置 node ，负荷功率 p_demand q_demand
ps.sgens # 电网的静态发电机信息，是 List[StaticGenerator] 类型
# StaticGenerator 类有下面成员：静态发电机所在节点位置 node ，注入功率 p_inject q_inject
ps.buses # 电网节点的限制信息，是 List[Dict] 类型， Dict 有 'min_v', 'max_v', 'vn_kv' 三个键值
# 电压幅值单位是 kV ，电机功率和负荷功率是 mW 和 mVar
\"\"\"
"""