import pandapower.networks as pn
import pandapower as ppower
import numpy as np
import json
import pandas as pd

from llmopf.netcase.IEEE15 import net_build_IEEE15
from llmopf.netcase.IEEE33 import net_build_IEEE33

from llmopf.config import get_para

eps = 1e-7

load_df = pd.read_csv('data_profile/load_profile.csv')
PV_df = pd.read_csv('data_profile/PV_profile.csv')
WT_df = pd.read_csv('data_profile/Wind_profile.csv')

load_num = load_df.shape[1] - 1
PV_num = PV_df.shape[1] - 1
WT_num = WT_df.shape[1] - 1

def read_csv_data(df, col_idx, time_slot):
    """
    读取 CSV 文件中的数据
    :param df: DataFrame 对象
    :param col_idx: 列索引
    :param time_slot: 时间槽索引
    :return: 读取的数据
    """
    if col_idx < 0 or col_idx >= df.shape[1]:
        raise ValueError("列索引超出范围")
    
    if time_slot < 0 or time_slot >= df.shape[0]:
        raise ValueError("时间槽索引超出范围")
    
    return df.iloc[time_slot, col_idx]

def read_load(load_idx, time_slot):
    return read_csv_data(load_df, load_idx + 1, time_slot)

def read_sgen(sgen_idx, time_slot):
    if (sgen_idx < PV_num):
        return read_csv_data(PV_df, sgen_idx + 1, time_slot)
    elif (sgen_idx < PV_num + WT_num):
        return read_csv_data(WT_df, sgen_idx - PV_num + 1, time_slot)
    else:
        raise ValueError("静态发电机索引超出范围")

class Generator:
    def __init__(self, node, cp0, cp1, cp2, cq0, cq1, cq2, min_p, max_p, min_q, max_q):
        self.node = node  # 发电机所处的节点位置
        self.cp2 = cp2    # 二次成本系数
        self.cp1 = cp1    # 一次成本系数
        self.cp0 = cp0    # 常数成本系数
        self.cq2 = cq2    # 二次成本系数
        self.cq1 = cq1    # 一次成本系数
        self.cq0 = cq0    # 常数成本系数

        self.min_p = min_p
        self.max_p = max_p
        self.min_q = min_q
        self.max_q = max_q

    def __str__(self):
        return (f"Generator(node={self.node}, cp0={self.cp0}, cp1={self.cp1}, cp2={self.cp2}, "
                f"cq0={self.cq0}, cq1={self.cq1}, cq2={self.cq2}, min_p={self.min_p}, max_p={self.max_p}, min_q={self.min_q}, max_q={self.max_q})")

class Load:
    def __init__(self, node, p_demand, q_demand):
        self.node = node          # 负荷所处的节点位置
        self.p_demand = p_demand  # 有功功率需求
        self.q_demand = q_demand  # 无功功率需求

    def __str__(self):
        return f"Load(node={self.node}, p_demand={self.p_demand}, q_demand={self.q_demand})"

class StaticGenerator:
    def __init__(self, node, p_inject, q_inject):
        self.node = node          # 静态发电机所处的节点位置
        self.p_inject = p_inject  # 有功功率注入
        self.q_inject = q_inject  # 无功功率注入

    def __str__(self):
        return f"StaticGenerator(node={self.node}, p_inject={self.p_inject}, q_inject={self.q_inject})"

class Bus:
    def __init__(self, node, min_kv, max_kv, vn_kv):
        self.node = node
        self.min_kv = min_kv
        self.max_kv = max_kv
        self.vn_kv = vn_kv
    
    def __str__(self):
        return f"Bus(node={self.node}, min_kv={self.min_kv}, max_kv={self.max_kv}, vn_kv={self.vn_kv})"

class Solution:
    def __init__(self, n, m):
        self.generator_p = np.zeros(m)  # 发电机有功功率
        self.generator_q = np.zeros(m)  # 发电机无功功率
        self.v = np.zeros(n)        # 电压幅值
        self.theta = np.zeros(n - 1)    # 电压相角（不含平衡节点)
    
    def __str__(self):
        return f"Solution(gp={self.generator_p}, gq={self.generator_q}, v={self.v}, theta={self.theta})"

class PowerSystem:
    def __init__(self, pandapower_net, time_slot=0):
        self.n = len(pandapower_net.bus)
        self.m = len(pandapower_net.gen)
        self.k = len(pandapower_net.load)
        self.s = len(pandapower_net.sgen)

        self.Y = self.calcAdmittanceMatrix(pandapower_net)

        self.generators = []
        self.generators_loc = pandapower_net.gen['bus'].values
        self.generators_min_p = pandapower_net.gen['min_p_mw'].values
        self.generators_max_p = pandapower_net.gen['max_p_mw'].values
        self.generators_min_q = pandapower_net.gen['min_q_mvar'].values
        self.generators_max_q = pandapower_net.gen['max_q_mvar'].values

        if 'poly_cost' in pandapower_net.keys() and len(pandapower_net.poly_cost) > 0:
            j = 0
            for i, row in pandapower_net.poly_cost.iterrows():
                if (row['et'] == 'gen'):
                    self.generators.append(
                        Generator(
                            self.generators_loc[j],
                            row['cp0_eur'], row['cp1_eur_per_mw'], row['cp2_eur_per_mw2'],
                            row['cq0_eur'], row['cq1_eur_per_mvar'], row['cq2_eur_per_mvar2'],
                            self.generators_min_p[j], self.generators_max_p[j], 
                            self.generators_min_q[j], self.generators_max_q[j]
                        )
                    )
                    j += 1
        else:
            for i in range(self.m):
                self.generators.append(
                    Generator(
                        self.generators_loc[i],
                        1, 1, 1,
                        1, 1, 1,
                        self.generators_min_p[i], self.generators_max_p[i], 
                        self.generators_min_q[i], self.generators_max_q[i]
                    )
                )
        
        self.loads = []
        for i, row in pandapower_net.load.iterrows():
            if (i < load_num):
                self.loads.append(Load(row['bus'], read_load(i, time_slot) * 1, read_load(i, time_slot) * 1 * 0.5))
        
        self.sgens = []
        for i, row in pandapower_net.sgen.iterrows():
            if (i < PV_num + WT_num):
                self.sgens.append(StaticGenerator(row['bus'], read_sgen(i, time_slot), read_sgen(i, time_slot)*0.3))
        
        self.buses = []

        for i, row in pandapower_net.bus.iterrows():
            self.buses.append(Bus(i, row['vn_kv'] * row['min_vm_pu'], row['vn_kv'] * row['max_vm_pu'], row['vn_kv']))
        
        # print(self)

    def calcAdmittanceMatrix(self, pp_net):
        df_bus = pp_net.bus
        Y = np.zeros((self.n, self.n), dtype=complex)
        omega = 2 * np.pi * 60  # 系统频率
        baseMVA = pp_net.sn_mva

        # 计算线路导纳
        for index, row in pp_net.line.iterrows():
            from_bus = row['from_bus']
            to_bus = row['to_bus']
            r = row['r_ohm_per_km'] * row['length_km']
            x = row['x_ohm_per_km'] * row['length_km']
            c = row['c_nf_per_km'] * row['length_km'] * 1e-9  # 转换为法拉
            g = row['g_us_per_km'] * row['length_km'] * 1e-6  # 转换为西门子

            y_series = 1 / (r + 1j * x)
            y_shunt = 1j * omega * c + g

            Y[from_bus, from_bus] += y_series + y_shunt * 0.5
            Y[to_bus, to_bus] += y_series + y_shunt * 0.5
            Y[from_bus, to_bus] -= y_series
            Y[to_bus, from_bus] -= y_series

        # 计算变压器导纳
        for index, row in pp_net.trafo.iterrows():
            hv_bus = row['hv_bus']
            lv_bus = row['lv_bus']
            vn_lv_kv = row['vn_lv_kv']
            vk_percent = row['vk_percent']
            i0_percent = row['i0_percent']
            sn_mva = row['sn_mva']

            zk = (vk_percent * 0.01) * (vn_lv_kv ** 2) / sn_mva
            zk_complex = complex(0, zk)

            ym = (i0_percent * 0.01) * (sn_mva / (vn_lv_kv ** 2))
            ym_complex = complex(ym, 0)

            Y[hv_bus, hv_bus] += (1 / zk_complex) + ym_complex
            Y[lv_bus, lv_bus] += (1 / zk_complex)
            Y[hv_bus, lv_bus] -= (1 / zk_complex)
            Y[lv_bus, hv_bus] -= (1 / zk_complex)

        return Y

    def __str__(self):
        generator_str = [str(g) for g in self.generators]
        load_str = [str(l) for l in self.loads]
        sgen_str = [str(s) for s in self.sgens]
        bus_str = [f'node{i}: {self.buses[i]}' for i in range(self.n)]
        return f"PowerSystem(node_num={self.n}, generator_num={self.m}, load_num={self.k}, admittance_matrix={self.Y}, generators(mw, mvar)={generator_str}, loads(mw, mvar)={load_str}, sgens(mw, mvar)={sgen_str}, buses(kv)={bus_str})"

    def textPrint(self, filename='power_system.txt'):
        # Help me save the information into a txt file of the power system in a human-readable format including:
        # 1. Number of nodes, generators, and loads
        # 2. Admittance matrix
        # 3. Generator information (node, cost coefficients if it has, power limits)
        # 4. Load information (node, power demand)
        # 5. Static generator information (node, power injection)
        # 6. Bus information (voltage limits)
        # Attention: the voltage magnitude is in kV, the generator power and load power are in mW and mVar respectively.
        # Save the power system information to a text file
        with open(filename, 'w') as f:
            f.write(f"Number of nodes: {self.n}\n")
            f.write(f"Number of generators: {self.m}\n")
            f.write(f"Number of loads: {self.k}\n\n")

            f.write("Admittance Matrix:\n")
            for row in self.Y:
                f.write(' '.join([f'{val:.4f}' for val in row]) + '\n')
            f.write('\n')

            f.write("Generators:\n")
            for g in self.generators:
                # mW and mVar are used for generator power limits
                f.write(f"Node: {g.node}, Cost Coefficients: ({g.cp0}, {g.cp1}, {g.cp2}), "
                        f"Power Limits: ({g.min_p} mW, {g.max_p} mW), ({g.min_q} mVar, {g.max_q} mVar)\n")
            f.write('\n')

            f.write("Loads:\n")
            for l in self.loads:
                # mW and mVar are used for load power demand
                f.write(f"Node: {l.node}, Power Demand: ({l.p_demand} mW, {l.q_demand} mVar)\n")
            f.write('\n')

            f.write("Static Generators:\n")
            for s in self.sgens:
                # mW and mVar are used for static generator power injection
                f.write(f"Node: {s.node}, Power Injection: ({s.p_inject} mW, {s.q_inject} mVar)\n")
            f.write('\n')

            f.write("Buses:\n")
            for i, bus in enumerate(self.buses):
                # kV is used for bus voltage limits
                f.write(f"Node: {i}, Min Voltage: {bus['min_v']} kV, Max Voltage: {bus['max_v']} kV, Nominal Voltage: {bus['vn_kv']} kV\n")

def get_ps():
    case = get_para('case')
    time_slot = get_para('time_slot')

    if case == 'case5':
        return PowerSystem(pn.case5(), time_slot)
    elif case == 'case9':
        return PowerSystem(pn.case9(), time_slot)
    elif case == 'case14':
        return PowerSystem(pn.case14(), time_slot)
    elif case == 'case15':
        return PowerSystem(net_build_IEEE15(), time_slot)
    elif case == 'case33':
        return PowerSystem(net_build_IEEE33(), time_slot)
    else:
        raise ValueError(f"Unknown case: {case}")