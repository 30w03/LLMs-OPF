import pandapower.networks as pn
import pandapower as ppower
import numpy as np
import json

from llmopf.response.qwen import get_response
from llmopf.utils.parse_output import parse_output

eps = 1e-7

class Generator:
    def __init__(self, node, cp0, cp1, cp2, cq0, cq1, cq2, min_p, max_p, min_q, max_q):
        self.node = node  # 发电机所处的节点位置
        self.cp2 = cp2    # 二次成本系数
        self.cp1 = cp1    # 一次成本系数
        self.cp0 = cp0    # 常数成本系数
        self.cq2 = cq2    # 二次成本系数
        self.cq1 = cq1    # 一次成本系数
        self.cq0 = cq0    # 常数成本系数

        self.min_p = min_p
        self.max_p = max_p
        self.min_q = min_q
        self.max_q = max_q

    def __str__(self):
        return (f"Generator(node={self.node}, cp0={self.cp0}, cp1={self.cp1}, cp2={self.cp2}, "
                f"cq0={self.cq0}, cq1={self.cq1}, cq2={self.cq2}, min_p={self.min_p}, max_p={self.max_p}, min_q={self.min_q}, max_q={self.max_q})")

class Load:
    def __init__(self, node, p_demand, q_demand):
        self.node = node          # 负荷所处的节点位置
        self.p_demand = p_demand  # 有功功率需求
        self.q_demand = q_demand  # 无功功率需求

    def __str__(self):
        return f"Load(node={self.node}, p_demand={self.p_demand}, q_demand={self.q_demand})"

class Solution:
    def __init__(self, n, m):
        self.generator_p = np.zeros(m)  # 发电机有功功率
        self.generator_q = np.zeros(m)  # 发电机无功功率
        self.v = np.zeros(n)        # 电压幅值
        self.theta = np.zeros(n - 1)    # 电压相角（不含平衡节点)
    
    def __str__(self):
        return f"Solution(gp={self.generator_p}, gq={self.generator_q}, v={self.v}, theta={self.theta})"

class PowerSystem:
    def __init__(self, pandapower_net, slack_node_loc = 0):
        self.n = len(pandapower_net.bus)
        self.m = len(pandapower_net.gen)
        self.k = len(pandapower_net.load)

        self.Y = self.calcAdmittanceMatrix(pandapower_net)

        # self.slack_node = slack_node_loc

        self.generators = []
        self.generators_loc = pandapower_net.gen['bus'].values
        self.generators_min_p = pandapower_net.gen['min_p_mw'].values
        self.generators_max_p = pandapower_net.gen['max_p_mw'].values
        self.generators_min_q = pandapower_net.gen['min_q_mvar'].values
        self.generators_max_q = pandapower_net.gen['max_q_mvar'].values

        k = 0

        for i, row in pandapower_net.poly_cost.iterrows():
            if (row['et'] == 'gen'):
                self.generators.append(
                    Generator(
                        self.generators_loc[k],
                        row['cp0_eur'], row['cp1_eur_per_mw'], row['cp2_eur_per_mw2'],
                        row['cq0_eur'], row['cq1_eur_per_mvar'], row['cq2_eur_per_mvar2'],
                        self.generators_min_p[k], self.generators_max_p[k], 
                        self.generators_min_q[k], self.generators_max_q[k]
                    )
                )
                k += 1
        
        self.loads = []
        for i, row in pandapower_net.load.iterrows():
            self.loads.append(Load(row['bus'], row['p_mw'], row['q_mvar']))
        
        self.buses = []

        for i, row in pandapower_net.bus.iterrows():
            self.buses.append({'min_v': int(row['vn_kv'] * row['min_vm_pu']), 'max_v': int(row['vn_kv'] * row['max_vm_pu']), 'vn_kv': int(row['vn_kv'])})
        
        # print(self)

    def calcAdmittanceMatrix(self, pp_net):
        df_bus = pp_net.bus
        Y = np.zeros((self.n, self.n), dtype=complex)
        omega = 2 * np.pi * 60  # 系统频率
        baseMVA = pp_net.sn_mva

        # 计算线路导纳
        for index, row in pp_net.line.iterrows():
            from_bus = row['from_bus']
            to_bus = row['to_bus']
            r = row['r_ohm_per_km'] * row['length_km']
            x = row['x_ohm_per_km'] * row['length_km']
            c = row['c_nf_per_km'] * row['length_km'] * 1e-9  # 转换为法拉
            g = row['g_us_per_km'] * row['length_km'] * 1e-6  # 转换为西门子

            y_series = 1 / (r + 1j * x)
            y_shunt = 1j * omega * c + g

            Y[from_bus, from_bus] += y_series + y_shunt * 0.5
            Y[to_bus, to_bus] += y_series + y_shunt * 0.5
            Y[from_bus, to_bus] -= y_series
            Y[to_bus, from_bus] -= y_series

        # 计算变压器导纳
        for index, row in pp_net.trafo.iterrows():
            hv_bus = row['hv_bus']
            lv_bus = row['lv_bus']
            vn_lv_kv = row['vn_lv_kv']
            vk_percent = row['vk_percent']
            i0_percent = row['i0_percent']
            sn_mva = row['sn_mva']

            zk = (vk_percent * 0.01) * (vn_lv_kv ** 2) / sn_mva
            zk_complex = complex(0, zk)

            ym = (i0_percent * 0.01) * (sn_mva / (vn_lv_kv ** 2))
            ym_complex = complex(ym, 0)

            Y[hv_bus, hv_bus] += (1 / zk_complex) + ym_complex
            Y[lv_bus, lv_bus] += (1 / zk_complex)
            Y[hv_bus, lv_bus] -= (1 / zk_complex)
            Y[lv_bus, hv_bus] -= (1 / zk_complex)

        return Y

    def __str__(self):
        generator_str = [str(g) for g in self.generators]
        load_str = [str(l) for l in self.loads]
        bus_str = [f'node{i}: {self.buses[i]}' for i in range(self.n)]
        return f"PowerSystem(node_num={self.n}, generator_num={self.m}, load_num={self.k}, admittance_matrix={self.Y}, balance_node={self.slack_node}, generators(mw, mvar)={generator_str}, loads(mw, mvar)={load_str}, buses(kv)={bus_str})"

    def textPrint(self):
        # Help me save the information into a txt file of the power system in a human-readable format including:
        # 1. Number of nodes, generators, and loads
        # 2. Admittance matrix
        # 3. Generator information (node, cost coefficients if it has, power limits)
        # 4. Load information (node, power demand)
        # 5. Bus information (voltage limits)
        with open('power_system.txt', 'w') as f:
            f.write(f"Number of nodes: {self.n}\n")
            f.write(f"Number of generators: {self.m}\n")
            f.write(f"Number of loads: {self.k}\n\n")

            f.write("Admittance Matrix:\n")
            for row in self.Y:
                f.write(' '.join([f'{val:.4f}' for val in row]) + '\n')
            f.write('\n')

            f.write("Generators:\n")
            for gen in self.generators:
                f.write(str(gen) + '\n')
            f.write('\n')

            f.write("Loads:\n")
            for load in self.loads:
                f.write(str(load) + '\n')
            f.write('\n')

            f.write("Buses:\n")
            for i, bus in enumerate(self.buses):
                f.write(f'Node {i}: {bus}\n')


# # 发电机经济成本
# def objectFunctionStr(power_system):
#     obj_func_string = ""
#     for i, gen in enumerate(power_system.generators):
#         obj_func_string += f" + ({gen.cp2} * p[{i}] ** 2 + {gen.cp1} * p[{i}] + {gen.cp0})"
#         obj_func_string += f" + ({gen.cq2} * q[{i}] ** 2 + {gen.cq1} * q[{i}] + {gen.cq0})"
#     return obj_func_string

# def flowFunctionStr(power_system):
#     Y = power_system.Y
#     n = power_system.n
#     slack_node = power_system.slack_node

#     v = [f'v[{i}]' for i in range(n)]
#     theta = ['' for _ in range(n)]

#     # 设置平衡节点相位
#     theta[slack_node] = '0'

#     j = 0
#     for i in range(n - 1):
#         if (j == slack_node):
#             j += 1
#         theta[j] = f'a[{i}]'
#         j += 1

#     # 计算潮流约束
#     p_balance = ['' for _ in range(n)]
#     q_balance = ['' for _ in range(n)]

#     for i in range(n):
#         for j in range(n):
#             theta_ij = f'{theta[i]} - {theta[j]}'
#             g = Y[i, j].real
#             b = Y[i, j].imag

#             if (abs(g) > 0):
#                 p_balance[i] += f' + {v[i]} * {v[j]} * ({g}) * cos({theta_ij})'
#             if (abs(b) > 0 and (i != j)):
#                 p_balance[i] += f' + {v[i]} * {v[j]} * ({b}) * sin({theta_ij})'
            
#             if (abs(g) > 0 and (i != j)):
#                 q_balance[i] += f' + {v[i]} * {v[j]} * ({g}) * sin({theta_ij})'
#             if (abs(b) > 0):
#                 q_balance[i] += f' - {v[i]} * {v[j]} * ({b}) * cos({theta_ij})'

#     for i, gen in enumerate(power_system.generators):
#         p_balance[gen.node] += f' - p[{i}]'
#         q_balance[gen.node] += f' - q[{i}]'

#     for load in power_system.loads:
#         p_balance[load.node] += f' + {load.p_demand}'
#         q_balance[load.node] += f' + {load.q_demand}'

#     ec_str = ''
#     for ele in p_balance:
#         ec_str += ele + ' = 0\n'
#     for ele in q_balance:
#         ec_str += ele + ' = 0\n'
    
#     return ec_str

# def limitsStr(power_system):
#     limits = ''

#     for i, ele in enumerate(power_system.buses):
#         min_v = ele['min_v']
#         max_v = ele['max_v']
#         limits += f'{min_v} <= v[{i}] <= {max_v}\n'
    
#     for i, ele in enumerate(power_system.generators):
#         min_p = ele.min_p
#         max_p = ele.max_p
#         limits += f'{min_p} <= p[{i}] <= {max_p}\n'

#         min_q = ele.min_q
#         max_q = ele.max_q
#         limits += f'{min_q} <= q[{i}] <= {max_q}\n'
    
#     return limits

# prompt_opf = """
# 使用内点法求解下面优化问题，输出最优解和最优值：
# 优化变量：
# [TODO:请根据下面式子分析优化变量的构成和写进代码的转化方法]
# 目标函数：
# [MASK:object_function]
# 等式约束：
# [MASK:equality_constraints]
# 不等式约束：
# [MASK:unequality_constraints]
# """

# def get_opf_problem(power_system):
#     obj = objectFunctionStr(power_system)
#     ec = flowFunctionStr(power_system)
#     uc = limitsStr(power_system)

#     prompt = prompt_opf
#     prompt = prompt.replace('[MASK:object_function]', obj)
#     prompt = prompt.replace('[MASK:equality_constraints]', ec)
#     prompt = prompt.replace('[MASK:unequality_constraints]', uc)

#     return prompt

# prompt_power_system = """
# ## 要求
# 根据下面电网的状态和参数，求解出每个节点的电压幅值(kv)、除平衡节点外的相角(rad)、发电机输出有功功率(mw)、发电机输出无功功率(mvar)，使得发电机的经济成本最低。

# ## 电网数据
# [MASK:power_system]

# ## 解题思路
# 0. 建模成带约束的优化问题，调用 scipy.optimize 的内点法求解器解决
# 1. 先总结出需要求解哪些变量，记为 x
# 2. 根据电网信息，写出计算目标函数的代码 def object_function(x)
# 3. 根据潮流方程，写出等式约束的代码 def equality_constraints(x)
# 4. 根据发电机输出功率限制和电压幅值限制，写出变量的上下界 bounds
# 5. 整合 2. 3. 4. 的代码片段为一份可执行代码，我会调用 python 解析器求解得到结果
# """

# def get_power_system(power_system):
#     return prompt_power_system.replace('[MASK:power_system]', str(power_system))

# prompt_lagrange = """
# # 整体要求
# 请帮我写一份 python 代码，调用内点法求解下面优化问题：
# # 问题描述
# 优化变量：
# [v a p q]
# 注意每个向量的维度： v \in R^n, **a \in R^(n-1)**, p \in R^m, q \in R^m
# 目标函数：
# [MASK:object_function]
# 等式约束：
# [MASK:equality_constraints]
# 不等式约束：
# [MASK:unequality_constraints]
# # 要求
# 1. 化简、去掉确认为 0 的项（系数为 0）
# 2. 必需写可以直接运行的完整代码，若公式太长，则试图使用矩阵简化描述
# 3. 不能省略任何等式约束的定义
# 4. 只回答带注释的代码，不需要更多的解释
# 5. a 的初值设为 0
# # 代码如下
# """

# class Lagrange:
#     def __init__(self, obj, ec, uc):
#         prompt = prompt_lagrange
#         prompt = prompt.replace('[MASK:object_function]', obj)
#         prompt = prompt.replace('[MASK:equality_constraints]', ec)
#         prompt = prompt.replace('[MASK:unequality_constraints]', uc)
#         prompt = prompt.replace('solution.', '')

#         # print(prompt)
        
#         f = open('prompt.txt', 'w')
#         f.write(prompt)
#         f.close()

#         self.opf = prompt

#         # response = get_response(prompt, model='qwen-max')

#         # f = open('response.txt', 'w')
#         # f.write(response)
#         # f.close()

def main_run():
    # 测试
    IEEE9 = pn.case9()
    ps = PowerSystem(IEEE9, 1)
    # solution, result = getOptimalFlow(ps, 10)
    # print("最优解：", solution, result)

    # ppower.runpp(IEEE9)

    # Lagrange(objectFunctionStr(ps), flowFunctionStr(ps), limitsStr(ps))

    # best = Solution(ps.n, ps.m)

    # print(objectFunctionStr(best, ps))
    # a, b = flowFunctinoStr(best, ps)
    # best.generator_p = IEEE9.res_gen['p_mw'].values * 1e6
    # best.generator_q = IEEE9.res_gen['q_mvar'].values * 1e6

    # vm = IEEE9.res_bus['vm_pu'].values * IEEE9.bus['vn_kv'].values * 1e3
    # best.v = vm[1:]

    # va = IEEE9.res_bus['va_degree'].values
    # best.theta = va[1:]

    # print(best)
    # print(estimateCurrentSolution(best, ps))
    # print(IEEE9.res_ext_grid)
    # best.v = IEEE9.res_bus['vm_'].values
    # best.generator_p = IEEE9.res_gen['p_mw'].values


# class PowerSystem2:
#     def __init__(self, ps: PowerSystem):
#         self.node_num = ps.n
#         self.generator_num = ps.m
#         self.load_num = ps.k
#         self.admittance_matrix = ps.Y
#         self.generators = [{'node': ele.node, 'cost_coefficients': (ele.cp0, ele.cp1, ele.cp2), 'active_power_limits': (ele.min_p, ele.max_p), 'reactive_power_limits': (ele.min_q, ele.max_q)} for ele in ps.generators]
#         self.loads = [{'node': ele.node, 'power_demand': (ele.p_demand, ele.q_demand)} for ele in ps.loads]
#         self.static_generators = [{'node': ele.node, 'power_injection': (ele.p_inject, ele.q_inject)} for ele in ps.sgens]
#         self.buses = [{'node': i, 'min_voltage': bus['min_v'], 'max_voltage': bus['max_v'], 'nominal_voltage': bus['vn_kv']} for i, bus in enumerate(ps.buses)]

# s = """

# """