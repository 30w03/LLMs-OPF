import pandas as pd
import pandapower as ppower

from llmopf.netcase.parameters import IEEE33_config as config33

def net_build_IEEE33():
    net_power = ppower.create_empty_network()

    bus_data_list = [
        [10, 1.05, 0.95],  # Bus 1
        [10, 1.05, 0.95],   # Bus 2
        [10, 1.05, 0.95],   # Bus 3
        [10, 1.05, 0.95],   # Bus 4
        [10, 1.05, 0.95],   # Bus 5
        [10, 1.05, 0.95],   # Bus 6
        [10, 1.05, 0.95],   # Bus 7
        [10, 1.05, 0.95],   # Bus 8
        [10, 1.05, 0.95],   # Bus 9
        [10, 1.05, 0.95],   # Bus 10
        [10, 1.05, 0.95],   # Bus 11
        [10, 1.05, 0.95],   # Bus 12
        [10, 1.05, 0.95],   # Bus 13
        [10, 1.05, 0.95],   # Bus 14
        [10, 1.05, 0.95],   # Bus 15
        [10, 1.05, 0.95],   # Bus 16
        [10, 1.05, 0.95],   # Bus 17
        [10, 1.05, 0.95],   # Bus 18
        [10, 1.05, 0.95],   # Bus 19
        [10, 1.05, 0.95],   # Bus 20
        [10, 1.05, 0.95],   # Bus 21
        [10, 1.05, 0.95],   # Bus 22
        [10, 1.05, 0.95],   # Bus 23
        [10, 1.05, 0.95],   # Bus 24
        [10, 1.05, 0.95],   # Bus 25
        [10, 1.05, 0.95],   # Bus 26
        [10, 1.05, 0.95],   # Bus 27
        [10, 1.05, 0.95],   # Bus 28
        [10, 1.05, 0.95],   # Bus 29
        [10, 1.05, 0.95],   # Bus 30
        [10, 1.05, 0.95],   # Bus 31
        [10, 1.05, 0.95],   # Bus 32
        [10, 1.05, 0.95]    # Bus 33
    ]

    bus_list = [0]

    for ele in bus_data_list:
        bus_list.append(ppower.create_bus(net_power, vn_kv=ele[0], name=f"Bus{len(bus_list)}", max_vm_pu=ele[1], min_vm_pu=ele[2]))

    line_data_list = [
        [1, 2, 0.5],  # Line from b1 to b2
        [2, 3, 0.5],  # Line from b2 to b3
        [3, 4, 0.5],  # Line from b3 to b4
        [4, 5, 0.5],  # Line from b4 to b5
        [5, 6, 0.5],  # Line from b5 to b6
        [6, 7, 0.5],  # Line from b6 to b7
        [7, 8, 0.5],  # Line from b7 to b8
        [8, 9, 0.5],  # Line from b8 to b9
        [9, 10, 0.5], # Line from b9 to b10
        [10, 11, 0.5],# Line from b10 to b11
        [11, 12, 0.5],# Line from b11 to b12
        [12, 13, 0.5],# Line from b12 to b13
        [13, 14, 0.5],# Line from b13 to b14
        [14, 15, 0.5],# Line from b14 to b15
        [15, 16, 0.5],# Line from b15 to b16
        [16, 17, 0.5],# Line from b16 to b17
        [17, 18, 0.5],# Line from b17 to b18

        [2, 19, 0.5], # Line from b2 to b19
        [19, 20, 0.5],# Line from b19 to b20
        [20, 21, 0.5],# Line from b20 to b21
        [21, 22, 0.5],# Line from b21 to b22

        [3, 23, 0.5], # Line from b3 to b23
        [23, 24, 0.5],# Line from b23 to b24
        [24, 25, 0.5],# Line from b24 to b25

        [6, 26, 0.5], # Line from b6 to b26
        [26, 27, 0.5],# Line from b26 to b27
        [27, 28, 0.5],# Line from b27 to b28
        [28, 29, 0.5],# Line from b28 to b29
        [29, 30, 0.5],# Line from b29 to b30
        [30, 31, 0.5],# Line from b30 to b31
        [31, 32, 0.5],# Line from b31 to b32
        [32, 33, 0.5] # Line from b32 to b33
    ]

    for ele in line_data_list:
        ppower.create_line(net_power, bus_list[ele[0]], bus_list[ele[1]], length_km=ele[2], std_type="NA2XS2Y 1x240 RM/25 6/10 kV", max_loading_percent=100)
    
    # ppower.create_ext_grid(net_power, bus=bus_list[1], name="Main Grid", max_p_mw=200, min_p_mw=-200, slack=True)  # 松弛节点
    # ppower.create_transformer(net_power, hv_bus=bus_list[1], lv_bus=bus_list[2], std_type="25 MVA 110/10 kV", name="Trafo",
    #                         max_loading_percent=100)  # 变压器功率不够的话带不动负荷

    # OPF需要设置static generator的controllable=False  https://github.com/e2nIEE/pandapower/issues/1361
    # tutorials里的历程不需要这样做

    ppower.create_sgen(net_power, bus=bus_list[9], p_mw=1.1, name="PV1", max_p_mw=config33['PV1_Max'], min_p_mw=0, controllable=True)
    ppower.create_sgen(net_power, bus=bus_list[19], p_mw=0.7, name="PV2", max_p_mw=config33['PV2_Max'], min_p_mw=0, controllable=True)
    ppower.create_sgen(net_power, bus=bus_list[24], p_mw=0.6, name="PV3", max_p_mw=config33['PV3_Max'], min_p_mw=0, controllable=True)
    ppower.create_sgen(net_power, bus=bus_list[4], p_mw=0.9, name="WT1", max_p_mw=config33['WT1_Max'], min_p_mw=0, controllable=True)
    ppower.create_sgen(net_power, bus=bus_list[29], p_mw=0.65, name="WT2", max_p_mw=config33['WT2_Max'], min_p_mw=0, controllable=True)

    # 定义发电机列表
    gen_list = [
        [4, 4, "DG1", config33['DG1_Max']],  # Generator at bus b4
        [7, 4.5, "DG2", config33['DG2_Max']],  # Generator at bus b7
        [10, 3.5, "DG3", config33['DG3_Max']],  # Generator at bus b10
        [15, 3, "DG4", config33['DG4_Max']],  # Generator at bus b15
        [27, 5, "DG5", config33['DG5_Max']]  # Generator at bus b27
    ]

    # 使用 for 循环创建发电机
    for gen in gen_list:
        bus, p_mw, _, max_dg = gen
        ppower.create_gen(net_power, bus=bus_list[bus], p_mw=p_mw, name=f"DG{bus}", max_p_mw=max_dg, min_p_mw=0,
                    max_q_mvar=max_dg*2, min_q_mvar=-max_dg*2, controllable=True)

    cnt = 0

    # 定义负载的参数列表
    load_params = [
        (4, 0.35),
        (5, 0.86),
        (7, 0.30),
        (8, 0.75),
        (9, 0.35),
        (10, 0.11),
        (12, 0.40),
        (13, 0.48),
        (14, 0.70),
        (15, 0.14),
        (16, 0.86),
        (17, 0.30),
        (18, 0.75),
        (20, 0.11),
        (21, 0.48),
        (24, 0.48),
        (25, 0.70),
        (28, 0.48),
        (29, 0.40),
        (30, 0.48),
        (31, 0.70),
        (33, 0.14)
    ]

    cnt = 0

    # 使用 for 循环创建负载
    for bus_index, p_mw in load_params:
        cnt += 1
        ppower.create_load(
            net_power,
            bus=bus_list[bus_index],
            p_mw=p_mw,
            q_mvar=p_mw*0.5,
            name=f"Load{cnt}",
            controllable=False
        )

    
    # print("===========power==============")
    # print(net_power)

    # print("===========gas==============")
    # print(net_gas)
    # print(net_gas.sink)

    # run_control(net_multi)

    # print("===========res==============")
    # print(net_power.res_bus)
    # print(net_gas.res_junction)

    return net_power
