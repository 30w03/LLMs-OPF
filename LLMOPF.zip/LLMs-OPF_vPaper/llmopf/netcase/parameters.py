"""
基本参数设置
"""

IEEE15_config = {
    'EES1_Max': 5,
    'EES2_Max': 5,
    'WT_Max': 5,
    'PV_Max': 5,
    'DG1_Max': 5,
    'DG2_Max': 5,
}

IEEE33_config = {
    'EES1_Max': 5,
    'EES2_Max': 5,
    'EES3_Max': 5,
    'EES4_Max': 5,
    'WT1_Max': 5,
    'WT2_Max': 5,
    'PV1_Max': 5,
    'PV2_Max': 5,
    'PV3_Max': 5,
    'DG1_Max': 20,
    'DG2_Max': 20,
    'DG3_Max': 20,
    'DG4_Max': 20,
    'DG5_Max': 20,
}
