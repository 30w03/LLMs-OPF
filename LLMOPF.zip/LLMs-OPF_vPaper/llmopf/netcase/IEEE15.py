import pandas as pd
import pandapower as ppower

from llmopf.netcase.parameters import IEEE15_config as config15

def net_build_IEEE15():
    """
    Return a multi-net and its P2G, G2P edges。

    return:
    Tuple[MultiNet, List]: multi-net and edge list
    """

    net_power = ppower.create_empty_network()

    b1 = ppower.create_bus(net_power, vn_kv=10, name="Bus1", max_vm_pu=1.05, min_vm_pu=0.95)
    b2 = ppower.create_bus(net_power, vn_kv=10, name="Bus2", max_vm_pu=1.05, min_vm_pu=0.95)
    b3 = ppower.create_bus(net_power, vn_kv=10, name="Bus3", max_vm_pu=1.05, min_vm_pu=0.95)
    b4 = ppower.create_bus(net_power, vn_kv=10, name="Bus4", max_vm_pu=1.05, min_vm_pu=0.95)
    b5 = ppower.create_bus(net_power, vn_kv=10, name="Bus5", max_vm_pu=1.05, min_vm_pu=0.95)
    b6 = ppower.create_bus(net_power, vn_kv=10, name="Bus6", max_vm_pu=1.05, min_vm_pu=0.95)
    b7 = ppower.create_bus(net_power, vn_kv=10, name="Bus7", max_vm_pu=1.05, min_vm_pu=0.95)
    b8 = ppower.create_bus(net_power, vn_kv=10, name="Bus8", max_vm_pu=1.05, min_vm_pu=0.95)
    b9 = ppower.create_bus(net_power, vn_kv=10, name="Bus9", max_vm_pu=1.05, min_vm_pu=0.95)
    b10 = ppower.create_bus(net_power, vn_kv=10, name="Bus10", max_vm_pu=1.05, min_vm_pu=0.95)
    b11 = ppower.create_bus(net_power, vn_kv=10, name="Bus11", max_vm_pu=1.05, min_vm_pu=0.95)
    b12 = ppower.create_bus(net_power, vn_kv=10, name="Bus12", max_vm_pu=1.05, min_vm_pu=0.95)
    b13 = ppower.create_bus(net_power, vn_kv=10, name="Bus13", max_vm_pu=1.05, min_vm_pu=0.95)
    b14 = ppower.create_bus(net_power, vn_kv=10, name="Bus14", max_vm_pu=1.05, min_vm_pu=0.95)
    b15 = ppower.create_bus(net_power, vn_kv=10, name="Bus15", max_vm_pu=1.05, min_vm_pu=0.95)

    ppower.create_line(net_power, b1, b2, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b2, b3, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b3, b4, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b4, b5, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b2, b9, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b9, b10, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b2, b6, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b6, b7, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b6, b8, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b3, b11, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b11, b12, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b12, b13, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b4, b14, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)
    ppower.create_line(net_power, b4, b15, length_km=0.5, std_type="NAYY 4x120 SE", max_loading_percent=100)

    # eg = ppower.create_ext_grid(net_power, bus=b1, name="Main Grid", max_p_mw=200, min_p_mw=-200, slack=True)  # 松弛节点
    # ppower.create_transformer(net_power, hv_bus=b1, lv_bus=b2, std_type="25 MVA 110/10 kV", name="Trafo", max_loading_percent=100)  # 变压器功率不够的话带不动负荷


    # If controllable = False, it should not be adjusted by OPF.
    ppower.create_load(net_power, bus=b4, p_mw=0.35, q_mvar=0.17, name="Load1", controllable=False)
    ppower.create_load(net_power, bus=b5, p_mw=0.86, q_mvar=0.43, name="Load2", controllable=False)
    ppower.create_load(net_power, bus=b7, p_mw=0.30, q_mvar=0.15, name="Load3", controllable=False)
    ppower.create_load(net_power, bus=b8, p_mw=0.75, q_mvar=0.37, name="Load4", controllable=False)
    ppower.create_load(net_power, bus=b11, p_mw=0.48, q_mvar=0.24, name="Load5", controllable=False)
    ppower.create_load(net_power, bus=b12, p_mw=0.40, q_mvar=0.20,  name="Load6", controllable=False)
    ppower.create_load(net_power, bus=b13, p_mw=0.48, q_mvar=0.24, name="Load7", controllable=False)
    ppower.create_load(net_power, bus=b14, p_mw=0.70, q_mvar=0.35, name="Load8", controllable=False)
    ppower.create_load(net_power, bus=b15, p_mw=0.14, q_mvar=0.07, name="Load9", controllable=False)

    # OPF需要设置static generator的controllable=False  https://github.com/e2nIEE/pandapower/issues/1361
    # tutorials里的历程不需要这样做
    sg1 = ppower.create_sgen(net_power, bus=b4, p_mw=1, q_mvar=0.3, name="WT", max_p_mw=config15['WT_Max'], min_p_mw=0,
                         min_q_mvar=0, max_q_mvar=10, controllable=True)

    sg2 = ppower.create_sgen(net_power, bus=b6, p_mw=1.1, q_mvar=-0.3, name="PV", max_p_mw=config15['PV_Max'], min_p_mw=0,
                            max_q_mvar=10, controllable=True)

    dg1 = ppower.create_gen(net_power, bus=b3, p_mw=4, name="DG1", max_p_mw=config15['DG1_Max'], min_p_mw=0, max_q_mvar=config15['DG1_Max']*2, min_q_mvar=config15['DG1_Max']*(-2),
                            vm_pu=1.01, max_vm_pu=1.05, min_vm_pu=0.95, controllable=True)

    dg2 = ppower.create_gen(net_power, bus=b9, p_mw=4, name="DG2", max_p_mw=config15['DG2_Max'], min_p_mw=0, max_q_mvar=config15['DG2_Max']*2, min_q_mvar=config15['DG2_Max']*(-2),
                            vm_pu=1.01, max_vm_pu=1.05, min_vm_pu=0.95, controllable=True)

    return net_power
