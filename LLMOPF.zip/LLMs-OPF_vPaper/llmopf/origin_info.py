origin_info_case5_obj1 = """
电网的信息存储在名字叫 ps 的 PowerSystem 类的实例中， ps 的定义如下：
import pandapower.networks as pn
from llmopf import powernet
ps = powernet.PowerSystem(pn.case5())
\"\"\"
ps.n # 电网的节点数量
ps.m # 电网的发电机数量
ps.k # 电网的负荷数量
ps.Y # 电网的导纳矩阵
ps.generators # 电网的发电机信息，是 List[Generator] 类型
# Generator 类有下面成员：发电机所在节点位置 node ，发电机成本系数 cp0 cp1 cp2 cq0 cq1 cq2 ，发电机功率限制 min_p max_p min_q max_q
ps.loads # 电网负荷信息，是 List[Load] 类型
# Load 类有下面成员：负荷所在节点位置 node ，负荷功率 p_demand q_demand
ps.buses # 电网节点的限制信息，是 List[Dict] 类型， Dict 有 'min_v', 'max_v' 两个键值
# 电压幅值单位是 kV ，电机功率和负荷功率是 mW 和 mVar
\"\"\"
该电网的运行目标是减少发电成本
"""

groundtruth_case5_obj1 = """
fun: 17491.852941161902, v: [252.071939   249.84725576 252.03706987 248.5269002  253.        ], a: [-2.00686521 -2.05942629 -2.05328375 -2.04877398 -1.98833309], p: [ 40.         364.39509804 600.        ], q: [ 30.         243.81504505  89.6262603 ]
"""

origin_info_case9_obj2 = """
电网的信息存储在名字叫 ps 的 PowerSystem 类的实例中， ps 的定义如下：
import pandapower.networks as pn
from llmopf import powernet
ps = powernet.PowerSystem(pn.case9())
\"\"\"
ps.n # 电网的节点数量
ps.m # 电网的发电机数量
ps.k # 电网的负荷数量
ps.Y # 电网的导纳矩阵
ps.generators # 电网的发电机信息，是 List[Generator] 类型
# Generator 类有下面成员：发电机所在节点位置 node ，发电机功率限制 min_p max_p min_q max_q
ps.loads # 电网负荷信息，是 List[Load] 类型
# Load 类有下面成员：负荷所在节点位置 node ，负荷功率 p_demand q_demand
ps.buses # 电网节点的限制信息，是 List[Dict] 类型， Dict 有 'min_v', 'max_v', 'vn_kv' 三个键值
# 电压幅值单位是 kV ，电机功率和负荷功率是 mW 和 mVar
\"\"\"
该电网的运行目标是保持电压稳定
"""

groundtruth_case9_obj2 = """
fun: 1411.2206308171776, v: [334.57953346 362.20595412 359.89363353 334.57953345 335.31389356 357.75010502 352.44234912 355.95573218 329.36731808], a: [-0.16797712  0.11502447  0.0857937  -0.16797712 -0.15871839  0.00764009 -0.02951469  0.01082376 -0.17501598], p: [180.26766523 144.1202237 ], q: [39.83267892 16.69494385]
"""

origin_info_case15_obj3 = """
电网的信息存储在名字叫 ps 的 PowerSystem 类的实例中， ps 的定义如下：
import pandapower.networks as pn
from llmopf import powernet
ps = powernet.PowerSystem(pn.case5())
\"\"\"
ps.n # 电网的节点数量
ps.m # 电网的发电机数量
ps.k # 电网的负荷数量
ps.Y # 电网的导纳矩阵
ps.generators # 电网的发电机信息，是 List[Generator] 类型
# Generator 类有下面成员：发电机所在节点位置 node ，发电机成本系数 cp0 cp1 cp2 cq0 cq1 cq2 ，发电机功率限制 min_p max_p min_q max_q
ps.loads # 电网负荷信息，是 List[Load] 类型
# Load 类有下面成员：负荷所在节点位置 node ，负荷功率 p_demand q_demand
ps.buses # 电网节点的限制信息，是 List[Dict] 类型， Dict 有 'min_v', 'max_v' 两个键值
# 电压幅值单位是 kV ，电机功率和负荷功率是 mW 和 mVar
\"\"\"
该电网的运行目标是减少发电成本
"""

groundtruth_case15_obj3 = """
fun: 17491.852941161902, v: [252.071939   249.84725576 252.03706987 248.5269002  253.        ], a: [-2.00686521 -2.05942629 -2.05328375 -2.04877398 -1.98833309], p: [ 40.         364.39509804 600.        ], q: [ 30.         243.81504505  89.6262603 ]
"""


net_info = """
电网的信息存储在名字叫 ps 的 PowerSystem 类的实例中， ps 的定义如下：
from lmaef.powernet import get_ps
ps = get_ps()
\"\"\"
ps.n # 电网的节点数量
ps.m # 电网的发电机数量
ps.k # 电网的负荷数量
ps.Y # 电网的导纳矩阵
ps.generators # 电网的发电机信息，是 List[Generator] 类型
# Generator 类有下面成员：发电机所在节点位置 node ，发电机功率限制 min_p max_p min_q max_q
ps.loads # 电网负荷信息，是 List[Load] 类型
# Load 类有下面成员：负荷所在节点位置 node ，负荷功率 p_demand q_demand
ps.sgens # 电网的静态发电机信息，是 List[StaticGenerator] 类型
# StaticGenerator 类有下面成员：静态发电机所在节点位置 node ，注入功率 p_inject q_inject
ps.buses # 电网节点的限制信息，是 List[Dict] 类型， Dict 有 'min_v', 'max_v', 'vn_kv' 三个键值
# 电压幅值单位是 kV ，电机功率和负荷功率是 mW 和 mVar
\"\"\"
"""

object_info_economy = """
该电网的运行目标是减少发电成本
"""

object_info_reliability = """
该电网的运行目标是保持电压稳定，具体来说，希望节点的电压尽量在参考电压附近。
"""

origin_info_0707 = """
电网的信息存储在名字叫 ps 的实例\变量中， ps 的获取方式如下：

from data_net_info.read_case import get_ps
ps = get_ps()  # 电网的信息存储在名字叫 ps 的实例/变量中
---
ps 的数据结构的描述：

**注意，如果是成员变量，请标注 self. 字样**

电网的节点数量、发电机数量：
- 节点数量：`self.num_nodes`
- 发电机数量：`self.num_generators`

电网的导纳矩阵：
- 导纳矩阵：`self.admittance_matrix`

电网的发电机 i 所在节点位置、有功功率约束、无功功率约束：
- 所在节点位置：`self.generators[i].node`
- 有功功率约束：`self.generators[i].active_power_limits`
- 无功功率约束：`self.generators[i].reactive_power_limits`

电网的负荷 i 所在节点位置、有功功率、无功功率：
- 所在节点位置：`self.loads[i].node`
- 有功功率：`self.loads[i].power_demand[0]`
- 无功功率：`self.loads[i].power_demand[1]`

电网的静态发电机 i 所在节点位置、注入的有功功率、无功功率：
- 所在节点位置：`self.static_generators[i].node`
- 注入的有功功率：`self.static_generators[i].power_injection[0]`
- 注入的无功功率：`self.static_generators[i].power_injection[1]`

电网节点 i 的约束，电压幅值最小值、最大值、标准值（如果有）：
- 电压幅值最小值：`self.buses[i].min_voltage`
- 电压幅值最大值：`self.buses[i].max_voltage`
- 电压幅值标准值：`self.buses[i].nominal_voltage`

检查电压的单位的平方是不是和功率单位对的上（kV 对 mW 和 mVar，V 对 W 和 Var）：
- 电压单位是 kV，功率单位是 mW 和 mVar。从物理公式来看，功率 $ P = V^2 / R $，如果电压单位是 kV，则 $ (kV)^2 $ 是 $ MVA \cdot R $，而 mW 和 mVar 是毫瓦和毫乏，即 $ 10^{-3} W $ 和 $ 10^{-3} Var $。因此，单位不匹配。
- 如果将电压单位改为 V，则 $ (V)^2 $ 是 $ VA \cdot R $，与 W 和 Var 匹配。所以建议统一使用 V 作为电压单位以确保单位一致性。
---
该电网的运行目标是保持电压稳定，具体来说，希望节点的电压尽量在参考电压附近。
"""