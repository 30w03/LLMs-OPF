# from llmopf.evaluate import evaluate
# from llmopf.evaluate_ex1 import evaluate as evaluate_ex1

# from llmopf.origin_info import origin_info_case5_obj1, groundtruth_case5_obj1
# from llmopf.origin_info import origin_info_case9_obj2, groundtruth_case9_obj2

# from llmopf.utils.experiment_record import make_experiment_record, write_record

# acc, tim, fun = evaluate_ex1('case5obj1', 50)

# record = make_experiment_record('qwen2.5-14b-instruct', 'case5obj1', 0, 0.8, 'LMAEF', 2, {'acc': acc, 'tim': tim, 'fun': fun})
# write_record(record)

from llmopf.response.base import get_response
from llmopf.powernet import get_ps
from llmopf.run import execute
from llmopf.config import set_para, get_opfcode
from llmopf.securitycheck import security_check
from llmopf.actions.executecode import execute_code
from llmopf.origin_info import origin_info_0707

# origin_info = """
# Here is the information of a power system, please calculate the optimal power flow with the object "minimal the cost of the generators".
# Number of nodes: 5
# Number of generators: 3
# Number of loads: 3

# Admittance Matrix:
# 0.0421-0.4206j -0.0067+0.0666j 0.0000+0.0000j -0.0062+0.0616j -0.0292+0.2924j
# -0.0067+0.0666j 0.0240-0.2399j -0.0173+0.1733j 0.0000+0.0000j 0.0000+0.0000j
# 0.0000+0.0000j -0.0173+0.1733j 0.0236-0.2363j -0.0063+0.0630j 0.0000+0.0000j
# -0.0062+0.0616j 0.0000+0.0000j -0.0063+0.0630j 0.0188-0.1876j -0.0063+0.0630j
# -0.0292+0.2924j 0.0000+0.0000j 0.0000+0.0000j -0.0063+0.0630j 0.0355-0.3554j

# Generators:
# Node: 0, Cost Coefficients: (0.0, 14.0, 0.0), Power Limits: (0.0 mW, 40.0 mW), (-30.0 mVar, 30.0 mVar)
# Node: 2, Cost Coefficients: (0.0, 30.0, 0.0), Power Limits: (0.0 mW, 520.0 mW), (-390.0 mVar, 390.0 mVar)
# Node: 4, Cost Coefficients: (0.0, 10.0, 0.0), Power Limits: (0.0 mW, 600.0 mW), (-450.0 mVar, 450.0 mVar)

# Loads:
# Node: 1, Power Demand: (0.7778323434178199 mW, 0.38891617170890996 mVar)
# Node: 2, Power Demand: (1.0453101187128575 mW, 0.5226550593564288 mVar)
# Node: 3, Power Demand: (0.3812661874438736 mW, 0.1906330937219368 mVar)

# Static Generators:
# Node: 0, Power Injection: (0.0 mW, 0.0 mVar)

# Buses:
# Node: 0, Min Voltage: 207.0 kV, Max Voltage: 253.00000000000003 kV, Nominal Voltage: 230.0 kV
# Node: 1, Min Voltage: 207.0 kV, Max Voltage: 253.00000000000003 kV, Nominal Voltage: 230.0 kV
# Node: 2, Min Voltage: 207.0 kV, Max Voltage: 253.00000000000003 kV, Nominal Voltage: 230.0 kV
# Node: 3, Min Voltage: 207.0 kV, Max Voltage: 253.00000000000003 kV, Nominal Voltage: 230.0 kV
# Node: 4, Min Voltage: 207.0 kV, Max Voltage: 253.00000000000003 kV, Nominal Voltage: 230.0 kV
# """

o = """
电网的信息存储在名字叫 ps 的实例\变量中， ps 的获取方式如下：

from llmopf.powernet import get_ps
ps = get_ps()  # 电网的信息存储在名叫 ps 的实例/变量中
---
ps 的数据结构的描述：

电网的节点数量：`self.n`
电网的发电机数量：`self.m`
电网的负荷数量：`self.k`
电网的导纳矩阵：`self.Y`

电网的发电机信息：
- 发电机 i 所在节点位置：`self.generators[i].node`
- 发电机 i 的有功功率约束，无功功率约束：`self.generators[i].min_p`, `self.generators[i].max_p`, `self.generators[i].min_q`, `self.generators[i].max_q`

电网负荷信息：
- 负荷 i 所在节点位置：`self.loads[i].node`
- 负荷 i 有功功率，无功功率：`self.loads[i].p_demand`, `self.loads[i].q_demand`

电网的静态发电机信息：
- 静态发电机 i 所在节点位置：`self.sgens[i].node`
- 静态发电机 i 注入的有功功率、无功功率：`self.sgens[i].p_inject`, `self.sgens[i].q_inject`

电网节点 i 的约束，电压幅值最小值、最大值、标准值（如果有）：
- 节点 i 的最小电压幅值：`self.buses[i].min_kv`
- 节点 i 的最大电压幅值：`self.buses[i].max_kv`
- 节点 i 的标准电压幅值：`self.buses[i].vn_kv`

检查电压的单位的平方是不是和功率单位对的上（kV 对 mW 和 mVar，V 对 W 和 Var）：
根据代码中的定义，电压单位为 kV，因此其平方单位为 kV^2。而功率单位为 mW 和 mVar，这与电压单位 kV 相匹配，因为功率单位可以视为电压单位的平方乘以电流单位。所以这里的单位是正确的。
---
该电网的运行目标是保持电压稳定，具体来说，希望节点的电压尽量在参考电压附近。
"""

o2 = """
电网的信息存储在名字叫 ps 的实例\变量中， ps 的获取方式如下：

from llmopf.powernet import get_ps
ps = get_ps()  # 电网的信息存储在名字叫 ps 的实例/变量中
---
ps 的数据结构的描述：

电网的节点数量、发电机数量、负荷数量、静态发电机数量：
- 节点数量：`self.n`
- 发电机数量：`self.m`
- 负荷数量：`self.k`
- 静态发电机数量：`self.s`

电网的导纳矩阵：
- 导纳矩阵：`self.Y`

电网的发电机 i 所在节点位置、有功功率约束、无功功率约束：
- 所在节点位置：`self.generators[i].node`
- 有功功率约束：`self.generators[i].min_p`, `self.generators[i].max_p`
- 无功功率约束：`self.generators[i].min_q`, `self.generators[i].max_q`

电网的负荷 i 所在节点位置、有功功率、无功功率：
- 所在节点位置：`self.loads[i].node`
- 有功功率：`self.loads[i].p_demand`
- 无功功率：`self.loads[i].q_demand`

电网的静态发电机 i 所在节点位置、注入的有功功率、无功功率：
- 所在节点位置：`self.sgens[i].node`
- 注入的有功功率：`self.sgens[i].p_inject`
- 注入的无功功率：`self.sgens[i].q_inject`

电网节点 i 的约束，电压幅值最小值、最大值、标准值（如果有）：
- 最小值：`self.buses[i].min_kv`
- 最大值：`self.buses[i].max_kv`
- 标准值：`self.buses[i].vn_kv`

检查电压的单位的平方是不是和功率单位对的上（kV 对 mW 和 mVar，V 对 W 和 Var）：
- 代码中使用的是 kV（千伏），而功率单位是 MW（兆瓦）和 MVar（兆乏）。根据电力系统公式 $ S = V \times I $，其中 $ S $ 是视在功率（单位为 VA 或 MVA），$ V $ 是电压（单位为 V 或 kV），$ I $ 是电流（单位为 A）。因此，如果电压以 kV 表示，功率以 MW 和 MVar 表示，则单位是匹配的。
---
该电网的运行目标是保持电压稳定，具体来说，希望节点的电压尽量在参考电压附近。
"""

set_para('LLM', 'qwen3-32b')

# o = origin_info_0707

# print(execute(o2))

set_para('case', 'case9')

# code = get_opfcode()

# ps = get_ps()

# print(ps)

# res = execute_code(code)

# print(res)


# print(get_response('Tell me some special speak in English.'))

print(security_check(0, 30))

# from llmopf.get_netinfo import get_net_info

# print(get_net_info(net_file='./data_net_info/read_case.py'))