import pandapower.networks as pn
import pandapower as ppower
import numpy as np
from scipy.optimize import minimize

class Generator:
    def __init__(self, node, cp0, cp1, cp2, cq0, cq1, cq2, min_p, max_p, min_q, max_q):
        self.node = node  # 发电机所处的节点位置
        self.cp2 = cp2    # 二次成本系数
        self.cp1 = cp1    # 一次成本系数
        self.cp0 = cp0    # 常数成本系数
        self.cq2 = cq2    # 二次成本系数
        self.cq1 = cq1    # 一次成本系数
        self.cq0 = cq0    # 常数成本系数

        self.min_p = min_p
        self.max_p = max_p
        self.min_q = min_q
        self.max_q = max_q

    def __str__(self):
        return (f"Generator(node={self.node}, cp0={self.cp0}, cp1={self.cp1}, cp2={self.cp2}, "
                f"cq0={self.cq0}, cq1={self.cq1}, cq2={self.cq2}, min_p={self.min_p}, max_p={self.max_p}, min_q={self.min_q}, max_q={self.max_q})")

class Load:
    def __init__(self, node, p_demand, q_demand):
        self.node = node          # 负荷所处的节点位置
        self.p_demand = p_demand  # 有功功率需求
        self.q_demand = q_demand  # 无功功率需求

    def __str__(self):
        return f"Load(node={self.node}, p_demand={self.p_demand}, q_demand={self.q_demand})"

class Solution:
    def __init__(self, n, m):
        self.generator_p = np.zeros(m)  # 发电机有功功率
        self.generator_q = np.zeros(m)  # 发电机无功功率
        self.v = np.zeros(n)        # 电压幅值
        self.theta = np.zeros(n - 1)    # 电压相角（不含平衡节点)
    
    def __str__(self):
        return f"Solution(gp={self.generator_p}, gq={self.generator_q}, v={self.v}, theta={self.theta})"

class PowerSystem:
    def __init__(self, pandapower_net, slack_node_loc):
        self.n = len(pandapower_net.bus)
        self.m = len(pandapower_net.gen)
        self.k = len(pandapower_net.load)

        self.Y = self.calcAdmittanceMatrix(pandapower_net)

        self.slack_node = slack_node_loc

        self.generators = []
        self.generators_loc = pandapower_net.gen['bus'].values
        self.generators_min_p = pandapower_net.gen['min_p_mw'].values
        self.generators_max_p = pandapower_net.gen['max_p_mw'].values
        self.generators_min_q = pandapower_net.gen['min_q_mvar'].values
        self.generators_max_q = pandapower_net.gen['max_q_mvar'].values

        k = 0

        for i, row in pandapower_net.poly_cost.iterrows():
            if (row['et'] == 'gen'):
                self.generators.append(
                    Generator(
                        self.generators_loc[k],
                        row['cp0_eur'], row['cp1_eur_per_mw'], row['cp2_eur_per_mw2'],
                        row['cq0_eur'], row['cq1_eur_per_mvar'], row['cq2_eur_per_mvar2'],
                        self.generators_min_p[k], self.generators_max_p[k], 
                        self.generators_min_q[k], self.generators_max_q[k]
                    )
                )
                k += 1
        
        self.loads = []
        for i, row in pandapower_net.load.iterrows():
            self.loads.append(Load(row['bus'], row['p_mw'], row['q_mvar']))
        
        self.buses = []

        for i, row in pandapower_net.bus.iterrows():
            self.buses.append({'min_v': int(row['vn_kv'] * row['min_vm_pu']), 'max_v': int(row['vn_kv'] * row['max_vm_pu']), 'vn_kv': int(row['vn_kv'])})
        
        # print(self)

    def calcAdmittanceMatrix(self, pp_net):
        df_bus = pp_net.bus
        Y = np.zeros((self.n, self.n), dtype=complex)
        omega = 2 * np.pi * 60  # 系统频率
        baseMVA = pp_net.sn_mva

        # 计算线路导纳
        for index, row in pp_net.line.iterrows():
            from_bus = row['from_bus']
            to_bus = row['to_bus']
            r = row['r_ohm_per_km'] * row['length_km']
            x = row['x_ohm_per_km'] * row['length_km']
            c = row['c_nf_per_km'] * row['length_km'] * 1e-9  # 转换为法拉
            g = row['g_us_per_km'] * row['length_km'] * 1e-6  # 转换为西门子

            y_series = 1 / (r + 1j * x)
            y_shunt = 1j * omega * c + g

            Y[from_bus, from_bus] += y_series + y_shunt * 0.5
            Y[to_bus, to_bus] += y_series + y_shunt * 0.5
            Y[from_bus, to_bus] -= y_series
            Y[to_bus, from_bus] -= y_series

        # 计算变压器导纳
        for index, row in pp_net.trafo.iterrows():
            hv_bus = row['hv_bus']
            lv_bus = row['lv_bus']
            vn_lv_kv = row['vn_lv_kv']
            vk_percent = row['vk_percent']
            i0_percent = row['i0_percent']
            sn_mva = row['sn_mva']

            zk = (vk_percent * 0.01) * (vn_lv_kv ** 2) / sn_mva
            zk_complex = complex(0, zk)

            ym = (i0_percent * 0.01) * (sn_mva / (vn_lv_kv ** 2))
            ym_complex = complex(ym, 0)

            Y[hv_bus, hv_bus] += (1 / zk_complex) + ym_complex
            Y[lv_bus, lv_bus] += (1 / zk_complex)
            Y[hv_bus, lv_bus] -= (1 / zk_complex)
            Y[lv_bus, hv_bus] -= (1 / zk_complex)

        return Y

    def __str__(self):
        generator_str = [str(g) for g in self.generators]
        load_str = [str(l) for l in self.loads]
        bus_str = [f'node{i}: {self.buses[i]}' for i in range(self.n)]
        return f"PowerSystem(node_num={self.n}, generator_num={self.m}, load_num={self.k}, admittance_matrix={self.Y}, slack_node={self.slack_node}, generators(mw, mvar)={generator_str}, loads(mw, mvar)={load_str}, buses(kv)={bus_str})"

power_net = pn.case9()
power_system = PowerSystem(power_net, 0)
# print(power_system)
n = power_system.n
m = power_system.m

def object_function(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    cost = 0

    for i in range(n):
        cost += (v[i] - power_system.buses[i]['vn_kv']) ** 2

    return cost

def equality_constraints(x):
    v = x[:n]
    a = x[n:n+n]
    p = x[n+n:n+n+m]
    q = x[n+n+m:n+n+m+m]

    Y = power_system.Y

    bp = np.zeros(n)
    bq = np.zeros(n)

    for i, gen in enumerate(power_system.generators):
        bp[gen.node] += p[i]
        bq[gen.node] += q[i]
    
    for load in power_system.loads:
        bp[load.node] -= load.p_demand
        bq[load.node] -= load.q_demand
    
    eq = []

    for i in range(n):
        pi = sum(v[i] * v[j] * (Y[i, j].real * np.cos(a[i] - a[j]) + Y[i, j].imag * np.sin(a[i] - a[j])) for j in range(n)) - bp[i]
        qi = sum(v[i] * v[j] * (Y[i, j].real * np.sin(a[i] - a[j]) - Y[i, j].imag * np.cos(a[i] - a[j])) for j in range(n)) - bq[i]

        eq.append(pi)
        eq.append(qi)
    
    return np.array(eq)

# 变量边界
v_bounds = [(bus['min_v'], bus['max_v']) for bus in power_system.buses]
a_bounds = [(-np.pi, np.pi)] * (n)
p_bounds = [(gen.min_p, gen.max_p) for gen in power_system.generators]
q_bounds = [(gen.min_q, gen.max_q) for gen in power_system.generators]

bounds = v_bounds + a_bounds + p_bounds + q_bounds

# 初始猜测值
initial_guess = np.zeros(n+n+m+m)

# 定义等式约束
eq_cons = {'type': 'eq', 'fun': lambda x: equality_constraints(x)}

# 求解最优潮流
result = minimize(object_function, initial_guess, method='SLSQP', bounds=bounds, constraints=[eq_cons])

print(result)

# 输出结果
print("Optimal solution found:")
print("Voltage magnitudes:", result.x[:n])
print("Phase angles:", result.x[n:n+n])
print("Active power generators:", result.x[n+n:n+n+m])
print("Reactive power generators:", result.x[n+n+m:n+n+m+m])
print("Total cost:", result.fun)

result_str = f'fun: {result.fun}, v: {result.x[:n]}, a: {result.x[n:n+n]}, p: {result.x[n+n:n+n+m]}, q: {result.x[n+n+m:n+n+m+m]}'

print(result_str)
