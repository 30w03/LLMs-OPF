import re
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class Generator:
    node: int
    cost_coefficients: Tuple[float, float, float]
    active_power_limits: Tuple[float, float]  # in mW
    reactive_power_limits: Tuple[float, float]  # in mVar

@dataclass
class Load:
    node: int
    power_demand: Tuple[float, float]  # (P in mW, Q in mVar)

@dataclass
class StaticGenerator:
    node: int
    power_injection: Tuple[float, float]  # (P in mW, Q in mVar)

@dataclass
class Bus:
    node: int
    min_voltage: float  # in kV
    max_voltage: float  # in kV
    nominal_voltage: float  # in kV

class PowerSystem:
    def __init__(self):
        self.num_nodes = 0
        self.num_generators = 0
        self.num_loads = 0
        self.admittance_matrix = []
        self.generators = [] # List[Generator]
        self.loads = [] # List[Load]
        self.static_generators = [] # List[StaticGenerator]
        self.buses = [] # List[Bus]
    
    def parse_complex(self, s: str) -> complex:
        """Parse a complex number string into a Python complex number
        
        Args:
            s: Complex number string in format like "a+bj" or "a-bj"
        
        Returns:
            Corresponding Python complex number
        
        Examples:
            >>> parse_complex("0.0421-0.4206j")
            (0.0421-0.4206j)
            >>> parse_complex("-0.0067+0.0666j")
            (-0.0067+0.0666j)
            >>> parse_complex("0.0000+0.0000j")
            0j
        """
        # Remove all whitespace and 'j' character
        s = s.replace(' ', '').replace('j', '')
        
        # Handle cases where imaginary part is zero (e.g., "1.0+0.0j")
        if s.endswith('+') or s.endswith('-'):
            s += '0.0'
        
        # Split into real and imaginary parts
        if '+' in s[1:]:  # Check for '+' not at start
            parts = s.split('+', 1)
            real_part = parts[0]
            imag_part = parts[1]
        elif '-' in s[1:]:  # Check for '-' not at start
            parts = s.split('-', 1)
            real_part = parts[0]
            imag_part = '-' + parts[1]
        else:
            # Only real part (e.g., "5.0" which would be "5.0+0.0j")
            return complex(float(s), 0.0)
        
        # Handle empty real part (e.g., "-0.5j" which is "-0.5")
        if not real_part:
            real_part = '0.0'
        
        return complex(float(real_part), float(imag_part))
    
    def extract_numbers(self, line):
        """专门用于电力系统数据的数字提取函数"""
        # 移除文本描述部分
        if ':' in line:
            line = line.split(':', 1)[1]
        
        # 处理括号内容
        line = re.sub(r'\([^)]*\)', lambda m: m.group(0).replace(' ', ','), line)
        
        # 提取所有数字（包括科学计数法）
        numbers = []
        for match in re.finditer(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?', line):
            num_str = match.group(0)
            # 处理可能的分隔符问题
            if num_str.startswith(('+', '-')) and (',' in num_str or ' ' in num_str):
                continue  # 可能是分割错误
            numbers.append(float(num_str))
        
        return numbers
    
    def parse_power_system(self, text: str):
        lines = text.split('\n')
        i = 0
        
        # Parse basic info
        while i < len(lines):
            line = lines[i].strip()
            if not line:
                i += 1
                continue
                
            if line.startswith("Number of nodes:"):
                self.num_nodes = int(self.extract_numbers(line)[0])
            elif line.startswith("Number of generators:"):
                self.num_generators = int(self.extract_numbers(line)[0])
            elif line.startswith("Number of loads:"):
                self.num_loads = int(self.extract_numbers(line)[0])
            elif line.startswith("Admittance Matrix:"):
                i += 1
                self.admittance_matrix = []
                for _ in range(self.num_nodes):
                    row = []
                    parts = lines[i].strip().split()
                    for part in parts:
                        row.append(self.parse_complex(part))
                    self.admittance_matrix.append(row)
                    i += 1
                continue
            elif line.startswith("Generators:"):
                i += 1
                while i < len(lines) and lines[i].strip() and not lines[i].strip().startswith("Loads:"):
                    if lines[i].strip().startswith("Node:"):
                        nums = self.extract_numbers(lines[i])
                        node = int(nums[0])
                        cost_coeffs = tuple(nums[1:4])
                        p_limits = tuple(nums[4:6])
                        q_limits = tuple(nums[6:8])
                        self.generators.append(Generator(node, cost_coeffs, p_limits, q_limits))
                    i += 1
                continue
            elif line.startswith("Loads:"):
                i += 1
                while i < len(lines) and lines[i].strip() and not lines[i].strip().startswith("Static Generators:"):
                    if lines[i].strip().startswith("Node:"):
                        nums = self.extract_numbers(lines[i])
                        node = int(nums[0])
                        demand = tuple(nums[1:3])
                        self.loads.append(Load(node, demand))
                    i += 1
                continue
            elif line.startswith("Static Generators:"):
                i += 1
                while i < len(lines) and lines[i].strip() and not lines[i].strip().startswith("Buses:"):
                    if lines[i].strip().startswith("Node:"):
                        nums = self.extract_numbers(lines[i])
                        node = int(nums[0])
                        injection = tuple(nums[1:3])
                        self.static_generators.append(StaticGenerator(node, injection))
                    i += 1
                continue
            elif line.startswith("Buses:"):
                i += 1
                while i < len(lines) and lines[i].strip():
                    if lines[i].strip().startswith("Node"):
                        nums = self.extract_numbers(lines[i])
                        node = int(nums[0])
                        min_v = nums[1]
                        max_v = nums[2]
                        nom_v = nums[3]
                        self.buses.append(Bus(node, min_v, max_v, nom_v))
                    i += 1
                continue
                
            i += 1

def get_ps():
    with open('./data_net_info/case33.txt', 'r') as f:
        text = f.read()
    
    system = PowerSystem()
    system.parse_power_system(text)

    return system

# 使用示例
if __name__ == "__main__":
    with open('./data_net_info/case33.txt', 'r') as f:
        text = f.read()
    
    system = PowerSystem()
    system.parse_power_system(text)
    
    # 打印部分信息验证
    print(f"Number of nodes: {system.num_nodes}")
    print(f"Admittance matrix size: {len(system.admittance_matrix)}x{len(system.admittance_matrix[0])}")
    print(f"First generator info: {system.generators[0]}")
    print(f"First load info: {system.loads[0]}")
    print(f"First bus info: {system.buses[0]}")